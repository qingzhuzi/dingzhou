#!/usr/bin/env python3
"""
定州文化之旅 - 桌面应用启动器
使用 PyWebView 将网页打包成桌面应用
"""

import webview
import os
import sys

def create_window():
    # 获取当前目录
    current_dir = os.path.dirname(os.path.abspath(__file__))
    
    # 创建窗口
    window = webview.create_window(
        title='定州文化之旅',
        url=os.path.join(current_dir, 'index.html'),
        width=1280,
        height=800,
        min_size=(800, 600),
        resizable=True,
        fullscreen=False,
        text_select=True
    )
    
    # 启动应用
    webview.start(gui='edge', debug=False)

if __name__ == '__main__':
    create_window()
