// 动态创建并注入关于我们模态框
function createAndInjectAboutModal() {
    const aboutModalHTML = `
    <div id="aboutModal" class="fixed inset-0 z-50 hidden items-center justify-center">
        <div class="absolute inset-0 bg-black/50" onclick="hideAboutModal()"></div>
        <div class="glass-card rounded-3xl p-6 sm:p-8 w-11/12 max-w-md relative z-10 animate-slide-up max-h-[80vh] overflow-y-auto">
            <div class="flex justify-between items-center mb-6">
                <h3 class="text-xl font-bold text-white">关于我们</h3>
                <button class="text-white hover:text-blue-300 transition-colors" onclick="hideAboutModal()">
                    <i class="fa fa-times text-xl"></i>
                </button>
            </div>
            <div class="space-y-6">
                <div class="text-center">
                    <img src="https://p26-flow-imagex-sign.byteimg.com/tos-cn-i-a9rns2rl98/rc/pc/super_tool/6521157daf3c462fb8e63aa311d310a6~tplv-a9rns2rl98-image.image?lk3s=8e244e95&rcl=20260209145959E368B756F237651ABBDC&rrcfp=f06b921b&x-expires=1773212413&x-signature=61TvSPJ6DnSFt9kVYiH0Hs4iA%2F0%3D" alt="定州塔" class="w-24 h-24 object-cover rounded-full mx-auto mb-4">
                    <h4 class="text-lg font-bold text-white">定州文化之旅团队</h4>
                    <p class="text-white/60 text-sm">我们致力于传播定州千年文化，为您提供最优质的旅游服务。</p>
                </div>
                <div>
                    <h5 class="font-semibold text-white mb-2">功能亮点</h5>
                    <ul class="text-white/70 text-sm space-y-2">
                        <li class="flex items-start space-x-2">
                            <i class="fa fa-star text-yellow-400 mt-1"></i>
                            <span>精美的毛玻璃效果和iOS风格设计</span>
                        </li>
                        <li class="flex items-start space-x-2">
                            <i class="fa fa-map-marker text-red-400 mt-1"></i>
                            <span>详细的景点、美食、年俗介绍</span>
                        </li>
                        <li class="flex items-start space-x-2">
                            <i class="fa fa-lightbulb-o text-yellow-400 mt-1"></i>
                            <span>智能的AI路线规划</span>
                        </li>
                        <li class="flex items-start space-x-2">
                            <i class="fa fa-users text-blue-400 mt-1"></i>
                            <span>活跃的用户讨论社区</span>
                        </li>
                    </ul>
                </div>
                <div>
                    <h5 class="font-semibold text-white mb-2">技术支持</h5>
                    <p class="text-white/70 text-sm">本应用由顶尖的前端开发团队打造，采用了最新的Web技术，为您带来流畅的用户体验。</p>
                </div>
                <div>
                    <h5 class="font-semibold text-white mb-2">联系方式</h5>
                    <p class="text-white/70 text-sm flex items-center space-x-2">
                        <i class="fa fa-envelope"></i>
                        <span>contact@dingzhoutravel.com</span>
                    </p>
                    <p class="text-white/70 text-sm flex items-center space-x-2">
                        <i class="fa fa-phone"></i>
                        <span>400-123-4567</span>
                    </p>
                </div>
                <div class="text-center text-white/50 text-xs">
                    <p>© 2026 定州文化之旅. All Rights Reserved.</p>
                    <p>版本 1.0.0</p>
                </div>
            </div>
        </div>
    </div>
    `;

    // 创建一个临时容器来解析HTML
    const tempContainer = document.createElement('div');
    tempContainer.innerHTML = aboutModalHTML;

    // 将模态框添加到body的末尾
    document.body.appendChild(tempContainer.firstElementChild);
}

// 修改 showAboutModal 函数，确保模态框存在
function showAboutModal() {
    // 检查模态框是否存在，如果不存在则创建
    if (!document.getElementById('aboutModal')) {
        createAndInjectAboutModal();
    }
    // 显示模态框
    document.getElementById('aboutModal').style.display = 'flex';
    document.body.style.overflow = 'hidden'; // 防止背景滚动
}

// 确保 hideAboutModal 函数存在
if (typeof hideAboutModal === 'undefined') {
    function hideAboutModal() {
        const modal = document.getElementById('aboutModal');
        if (modal) {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto'; // 恢复背景滚动
        }
    }
}

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', function() {
    // 预创建模态框，确保万无一失
    createAndInjectAboutModal();
});
