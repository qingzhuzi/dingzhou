// 国际化配置文件
const i18n = {
    currentLang: 'zh',
    
    translations: {
        zh: {
            // 导航栏
            'nav.title': '定州文化之旅',
            'nav.search': '搜索',
            'nav.messages': '消息通知',
            'nav.menu': '菜单',
            'nav.update': '更新公告',
            
            // 首页
            'home.hotAttractions': '热门景点',
            'home.featuredFood': '特色美食',
            'home.traditionalCulture': '传统民俗',
            'home.viewAll': '查看全部',
            'home.viewDetails': '查看详情',
            'home.aiRoute': 'AI智能规划路线',
            'home.aiPlaceholder': '告诉我您想去哪里，我来帮您规划...',
            'home.aiSubmit': '规划',
            
            // 底部导航
            'bottom.home': '首页',
            'bottom.discussion': '讨论',
            'bottom.profile': '我的',
            
            // 讨论页
            'discussion.title': '讨论区',
            'discussion.subtitle': '旅游讨论',
            'discussion.subtitleDesc': '分享您的定州旅游经历，与其他旅行者交流心得',
            'discussion.publish': '发布讨论',
            'discussion.publishTitle': '发布讨论',
            'discussion.loadMore': '加载更多',
            'discussion.allLoaded': '已加载全部内容',
            'discussion.placeholder': '分享您的旅行心得...',
            'discussion.send': '发送',
            'discussion.reply': '回复',
            'discussion.replies': '条回复',
            'discussion.like': '点赞',
            'discussion.comment': '评论',
            'discussion.share': '分享',
            'discussion.shareTitle': '分享',
            'discussion.shareText': '分享到',
            'discussion.cancel': '取消',
            'discussion.copyLink': '复制链接',
            
            // 菜单栏
            'menu.home': '首页',
            'menu.discussion': '讨论',
            'menu.profile': '我的',
            'menu.settings': '设置',
            'menu.about': '关于我们',
            'menu.help': '帮助中心',
            'menu.feedback': '意见反馈',
            'menu.share': '分享',
            
            // 我的页面
            'profile.title': '我的',
            'profile.editInfo': '编辑资料',
            'profile.browsingHistory': '浏览历史',
            'profile.favorites': '收藏',
            'profile.likes': '点赞',
            'profile.settings': '设置',
            'profile.about': '关于我们',
            'profile.help': '帮助中心',
            'profile.feedback': '意见反馈',
            'profile.joinDate': '加入',
            'profile.location': '未设置',
            
            // 设置
            'settings.title': '设置',
            'settings.darkMode': '深色模式',
            'settings.darkModeDesc': '开启后，应用将使用深色模式。',
            'settings.language': '语言',
            'settings.languageDesc': '选择应用显示语言。',
            'settings.chinese': '中文',
            'settings.english': 'English',
            
            // 消息通知
            'messages.title': '消息通知',
            'messages.clearAll': '清空所有消息',
            'messages.profile': '个人资料',
            'messages.welcome': '欢迎加入',
            
            // 更新公告
            'update.title': '定州文化之旅',
            'update.content': '本次更新',
            'update.newUI': '全新UI设计',
            'update.newUIDesc': '采用现代化玻璃拟态设计风格，视觉体验全面升级',
            'update.newUX': '全新UX体验',
            'update.newUXDesc': '优化交互流程，操作更流畅自然，用户体验大幅提升',
            'update.darkMode': '浅色/深色模式',
            'update.darkModeDesc': '支持浅色与深色主题切换，保护眼睛，随心所欲',
            'update.search': '智能搜索',
            'update.searchDesc': '新增全局搜索功能，快速查找景点、美食、文化内容',
            'update.sidebar': '侧边菜单栏',
            'update.sidebarDesc': '全新侧边导航设计，功能入口一目了然',
            'update.bottomNav': '底部导航栏',
            'update.bottomNavDesc': '便捷底部导航，单手操作更轻松',
            'update.notifications': '消息通知中心',
            'update.notificationsDesc': '实时消息推送，重要信息不遗漏',
            'update.community': '讨论社区',
            'update.communityDesc': '新增讨论区功能，分享旅行心得，交流互动',
            'update.feedback': '反馈系统',
            'update.feedbackDesc': '意见反馈通道，您的建议我们认真倾听',
            'update.fixes': '问题修复',
            'update.fixesDesc': '修复多项已知问题，稳定性与性能全面提升',
            'update.gotIt': '知道了',
            
            // 反馈
            'feedback.title': '意见反馈',
            'feedback.type': '反馈类型',
            'feedback.bug': '问题反馈',
            'feedback.suggestion': '功能建议',
            'feedback.other': '其他',
            'feedback.content': '反馈内容',
            'feedback.contentPlaceholder': '请详细描述您的问题或建议...',
            'feedback.contact': '联系方式',
            'feedback.contactPlaceholder': '请输入您的联系方式（选填）',
            'feedback.submit': '提交反馈',
            'feedback.success': '感谢您的反馈！我们会认真处理。',
            
            // 关于我们
            'about.title': '关于我们',
            'about.welcome': '定州欢迎您',
            
            // 帮助中心
            'help.title': '帮助中心',
            
            // 通用
            'common.cancel': '取消',
            'common.confirm': '确认',
            'common.save': '保存',
            'common.close': '关闭',
            'common.back': '返回',
            'common.loading': '加载中...',
            'common.success': '操作成功',
            'common.error': '操作失败',
            'common.retry': '重试',
            
            // 景点详情
            'detail.introduction': '景点介绍',
            'detail.history': '历史渊源',
            'detail.features': '特色亮点',
            'detail.location': '位置',
            'detail.hours': '开放时间',
            'detail.navigate': '导航',
            
            // 美食详情
            'food.introduction': '美食介绍',
            'food.reasons': '推荐理由',
            
            // 民俗详情
            'culture.introduction': '民俗介绍',
            'culture.activities': '活动内容'
        },
        
        en: {
            // Navigation
            'nav.title': 'Dingzhou Cultural Journey',
            'nav.search': 'Search',
            'nav.messages': 'Messages',
            'nav.menu': 'Menu',
            'nav.update': 'Updates',
            
            // Home
            'home.hotAttractions': 'Popular Attractions',
            'home.featuredFood': 'Local Cuisine',
            'home.traditionalCulture': 'Traditional Culture',
            'home.viewAll': 'View All',
            'home.viewDetails': 'Details',
            'home.aiRoute': 'AI Route Planner',
            'home.aiPlaceholder': 'Tell me where you want to go...',
            'home.aiSubmit': 'Plan',
            
            // Bottom Navigation
            'bottom.home': 'Home',
            'bottom.discussion': 'Discussion',
            'bottom.profile': 'Profile',
            
            // Discussion
            'discussion.title': 'Discussion',
            'discussion.subtitle': 'Travel Discussion',
            'discussion.subtitleDesc': 'Share your Dingzhou travel experiences and connect with fellow travelers',
            'discussion.publish': 'Post',
            'discussion.publishTitle': 'Post Discussion',
            'discussion.loadMore': 'Load More',
            'discussion.allLoaded': 'All content loaded',
            'discussion.placeholder': 'Share your travel experiences...',
            'discussion.send': 'Send',
            'discussion.reply': 'Reply',
            'discussion.replies': 'replies',
            'discussion.like': 'Like',
            'discussion.comment': 'Comment',
            'discussion.share': 'Share',
            'discussion.shareTitle': 'Share',
            'discussion.shareText': 'Share to',
            'discussion.cancel': 'Cancel',
            'discussion.copyLink': 'Copy Link',
            
            // Menu
            'menu.home': 'Home',
            'menu.discussion': 'Discussion',
            'menu.profile': 'Profile',
            'menu.settings': 'Settings',
            'menu.about': 'About Us',
            'menu.help': 'Help Center',
            'menu.feedback': 'Feedback',
            'menu.share': 'Share',
            
            // Profile
            'profile.title': 'Profile',
            'profile.editInfo': 'Edit Profile',
            'profile.browsingHistory': 'Browsing History',
            'profile.favorites': 'Favorites',
            'profile.likes': 'Likes',
            'profile.settings': 'Settings',
            'profile.about': 'About Us',
            'profile.help': 'Help Center',
            'profile.feedback': 'Feedback',
            'profile.joinDate': 'Joined',
            'profile.location': 'Not set',
            
            // Settings
            'settings.title': 'Settings',
            'settings.darkMode': 'Dark Mode',
            'settings.darkModeDesc': 'Enable dark mode for the app.',
            'settings.language': 'Language',
            'settings.languageDesc': 'Select display language.',
            'settings.chinese': '中文',
            'settings.english': 'English',
            
            // Messages
            'messages.title': 'Messages',
            'messages.clearAll': 'Clear All Messages',
            'messages.profile': 'Profile',
            'messages.welcome': 'Welcome',
            
            // Update
            'update.title': 'Dingzhou Cultural Journey',
            'update.content': 'What\'s New',
            'update.newUI': 'Brand New UI',
            'update.newUIDesc': 'Modern glassmorphism design with enhanced visual experience',
            'update.newUX': 'Enhanced UX',
            'update.newUXDesc': 'Optimized interactions for smoother user experience',
            'update.darkMode': 'Light/Dark Mode',
            'update.darkModeDesc': 'Switch between light and dark themes',
            'update.search': 'Smart Search',
            'update.searchDesc': 'Global search for attractions, food, and culture',
            'update.sidebar': 'Side Menu',
            'update.sidebarDesc': 'New sidebar navigation design',
            'update.bottomNav': 'Bottom Navigation',
            'update.bottomNavDesc': 'Convenient bottom navigation for easy access',
            'update.notifications': 'Notification Center',
            'update.notificationsDesc': 'Real-time push notifications',
            'update.community': 'Discussion Community',
            'update.communityDesc': 'Share travel experiences and interact',
            'update.feedback': 'Feedback System',
            'update.feedbackDesc': 'Share your suggestions with us',
            'update.fixes': 'Bug Fixes',
            'update.fixesDesc': 'Improved stability and performance',
            'update.gotIt': 'Got It',
            
            // Feedback
            'feedback.title': 'Feedback',
            'feedback.type': 'Type',
            'feedback.bug': 'Bug Report',
            'feedback.suggestion': 'Suggestion',
            'feedback.other': 'Other',
            'feedback.content': 'Content',
            'feedback.contentPlaceholder': 'Please describe your issue or suggestion...',
            'feedback.contact': 'Contact',
            'feedback.contactPlaceholder': 'Your contact info (optional)',
            'feedback.submit': 'Submit',
            'feedback.success': 'Thank you for your feedback!',
            
            // About
            'about.title': 'About Us',
            'about.welcome': 'Welcome to Dingzhou',
            
            // Help
            'help.title': 'Help Center',
            
            // Common
            'common.cancel': 'Cancel',
            'common.confirm': 'Confirm',
            'common.save': 'Save',
            'common.close': 'Close',
            'common.back': 'Back',
            'common.loading': 'Loading...',
            'common.success': 'Success',
            'common.error': 'Error',
            'common.retry': 'Retry',
            
            // Detail
            'detail.introduction': 'Introduction',
            'detail.history': 'History',
            'detail.features': 'Highlights',
            'detail.location': 'Location',
            'detail.hours': 'Hours',
            'detail.navigate': 'Navigate',
            
            // Food
            'food.introduction': 'Introduction',
            'food.reasons': 'Recommendations',
            
            // Culture
            'culture.introduction': 'Introduction',
            'culture.activities': 'Activities'
        }
    },
    
    // 获取当前语言
    getLang() {
        return this.currentLang;
    },
    
    // 设置语言
    setLang(lang) {
        this.currentLang = lang;
        localStorage.setItem('dingzhou_language', lang);
        this.updatePage();
    },
    
    // 获取翻译文本
    t(key) {
        return this.translations[this.currentLang][key] || key;
    },
    
    // 初始化
    init() {
        const savedLang = localStorage.getItem('dingzhou_language');
        if (savedLang) {
            this.currentLang = savedLang;
        }
        this.updatePage();
    },
    
    // 更新页面文本
    updatePage() {
        document.querySelectorAll('[data-i18n]').forEach(el => {
            const key = el.getAttribute('data-i18n');
            const text = this.t(key);
            if (text) {
                el.textContent = text;
            }
        });
        
        document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
            const key = el.getAttribute('data-i18n-placeholder');
            const text = this.t(key);
            if (text) {
                el.placeholder = text;
            }
        });
        
        // 更新语言按钮样式
        this.updateLanguageButtons();
    },
    
    // 更新语言按钮样式
    updateLanguageButtons() {
        const langZh = document.getElementById('langZh');
        const langEn = document.getElementById('langEn');
        if (langZh && langEn) {
            if (this.currentLang === 'zh') {
                langZh.className = 'px-3 py-1.5 rounded-lg text-sm font-medium transition-all bg-primary text-white';
                langEn.className = 'px-3 py-1.5 rounded-lg text-sm font-medium transition-all bg-white/10 text-white/70 hover:bg-white/20';
            } else {
                langZh.className = 'px-3 py-1.5 rounded-lg text-sm font-medium transition-all bg-white/10 text-white/70 hover:bg-white/20';
                langEn.className = 'px-3 py-1.5 rounded-lg text-sm font-medium transition-all bg-primary text-white';
            }
        }
    }
};

// 页面加载时初始化
document.addEventListener('DOMContentLoaded', function() {
    i18n.init();
});
