/**
 * 主入口文件
 * 初始化所有模块
 */

(function() {
    'use strict';

    console.log('Initializing Dingzhou Travel App...');

    // 初始化浏览器兼容性检测
    if (window.BrowserCompat) {
        try {
            BrowserCompat.init();
        } catch (e) {
            console.warn('BrowserCompat初始化失败:', e);
        }
    }

    // 初始化错误处理
    if (window.ErrorHandler) {
        try {
            ErrorHandler.init();
        } catch (e) {
            console.warn('ErrorHandler初始化失败:', e);
        }
    }

    // 加载数据
    if (window.DataLoader) {
        DataLoader.loadAll().then(function() {
            console.log('数据加载完成');
        }).catch(function(err) {
            console.error('数据加载失败:', err);
        });
    }

    console.log('App initialized successfully!');
})();
