/**
 * 动态加载HTML组件
 */
async function loadComponents() {
    try {
        // 加载导航栏组件
        const navbarResponse = await fetch('assets/components/navbar.html');
        const navbarHtml = await navbarResponse.text();
        
        // 将导航栏组件插入到页面中
        const navbarContainer = document.getElementById('navbar-container');
        if (navbarContainer) {
            navbarContainer.innerHTML = navbarHtml;
        }
    } catch (error) {
        console.error('加载组件失败:', error);
    }
}

// 页面加载完成后加载组件
document.addEventListener('DOMContentLoaded', loadComponents);