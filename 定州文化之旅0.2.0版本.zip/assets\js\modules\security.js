/**
 * 安全模块
 * 包含输入验证、XSS防护、CSRF防护等安全相关功能
 */

// 安全模块
const SecurityModule = {
    // 初始化安全功能
    init: function() {
        console.log('Security module initialized');
        this.initInputValidation();
        this.initXSSProtection();
        this.initCSRFProtection();
        this.initSecureStorage();
        this.initContentSecurityPolicy();
    },
    
    // 初始化输入验证
    initInputValidation: function() {
        // 为所有输入元素添加验证
        const inputElements = document.querySelectorAll('input, textarea, select');
        inputElements.forEach(element => {
            // 添加输入事件监听器
            element.addEventListener('input', (e) => {
                this.validateInput(e.target);
            });
            
            // 添加提交事件监听器
            element.addEventListener('change', (e) => {
                this.validateInput(e.target);
            });
        });
        
        // 为表单添加提交验证
        const forms = document.querySelectorAll('form');
        forms.forEach(form => {
            form.addEventListener('submit', (e) => {
                if (!this.validateForm(form)) {
                    e.preventDefault();
                    this.showValidationError('请检查表单输入是否正确');
                }
            });
        });
    },
    
    // 验证单个输入
    validateInput: function(input) {
        const type = input.type;
        const value = input.value;
        const required = input.required;
        const minLength = input.minLength;
        const maxLength = input.maxLength;
        const pattern = input.pattern;
        
        // 检查必填项
        if (required && !value.trim()) {
            this.markInputInvalid(input, '此字段为必填项');
            return false;
        }
        
        // 检查最小长度
        if (minLength && value.length < minLength) {
            this.markInputInvalid(input, `最少需要${minLength}个字符`);
            return false;
        }
        
        // 检查最大长度
        if (maxLength && value.length > maxLength) {
            this.markInputInvalid(input, `最多允许${maxLength}个字符`);
            return false;
        }
        
        // 检查正则表达式模式
        if (pattern && value) {
            const regex = new RegExp(pattern);
            if (!regex.test(value)) {
                this.markInputInvalid(input, '输入格式不正确');
                return false;
            }
        }
        
        // 检查特定类型
        switch (type) {
            case 'email':
                if (value && !this.isValidEmail(value)) {
                    this.markInputInvalid(input, '请输入有效的邮箱地址');
                    return false;
                }
                break;
            case 'url':
                if (value && !this.isValidURL(value)) {
                    this.markInputInvalid(input, '请输入有效的URL地址');
                    return false;
                }
                break;
            case 'number':
                if (value && !this.isValidNumber(value)) {
                    this.markInputInvalid(input, '请输入有效的数字');
                    return false;
                }
                break;
        }
        
        // 输入有效
        this.markInputValid(input);
        return true;
    },
    
    // 验证表单
    validateForm: function(form) {
        let isValid = true;
        const inputs = form.querySelectorAll('input, textarea, select');
        
        inputs.forEach(input => {
            if (!this.validateInput(input)) {
                isValid = false;
            }
        });
        
        return isValid;
    },
    
    // 标记输入为无效
    markInputInvalid: function(input, message) {
        // 移除之前的错误信息
        const existingError = input.parentElement.querySelector('.error-message');
        if (existingError) {
            existingError.remove();
        }
        
        // 添加错误样式
        input.classList.add('border-red-500');
        input.classList.remove('border-green-500');
        
        // 添加错误信息
        const errorElement = document.createElement('div');
        errorElement.className = 'error-message text-red-500 text-xs mt-1';
        errorElement.textContent = message;
        input.parentElement.appendChild(errorElement);
    },
    
    // 标记输入为有效
    markInputValid: function(input) {
        // 移除之前的错误信息
        const existingError = input.parentElement.querySelector('.error-message');
        if (existingError) {
            existingError.remove();
        }
        
        // 添加有效样式
        input.classList.remove('border-red-500');
        input.classList.add('border-green-500');
    },
    
    // 显示验证错误
    showValidationError: function(message) {
        if (typeof UXModule !== 'undefined' && UXModule.showNotification) {
            UXModule.showNotification(message, 'error', 3000);
        } else {
            alert(message);
        }
    },
    
    // 验证邮箱
    isValidEmail: function(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    },
    
    // 验证URL
    isValidURL: function(url) {
        try {
            new URL(url);
            return true;
        } catch {
            return false;
        }
    },
    
    // 验证数字
    isValidNumber: function(value) {
        return !isNaN(value) && isFinite(value);
    },
    
    // 初始化XSS防护
    initXSSProtection: function() {
        // 添加内容安全策略
        this.addContentSecurityPolicy();
        
        // 为所有用户输入添加转义
        this.setupXSSFilters();
    },
    
    // 添加内容安全策略
    addContentSecurityPolicy: function() {
        const cspHeader = "default-src 'self'; script-src 'self' https://cdn.jsdelivr.net; style-src 'self' https://cdn.jsdelivr.net 'unsafe-inline'; img-src 'self' data: https:; font-src 'self' https://cdn.jsdelivr.net; connect-src 'self' https:;";
        
        // 检查是否已经存在CSP
        const existingMeta = document.querySelector('meta[http-equiv="Content-Security-Policy"]');
        if (existingMeta) {
            existingMeta.setAttribute('content', cspHeader);
        } else {
            const meta = document.createElement('meta');
            meta.httpEquiv = 'Content-Security-Policy';
            meta.content = cspHeader;
            document.head.appendChild(meta);
        }
    },
    
    // 设置XSS过滤器
    setupXSSFilters: function() {
        // 为所有输入添加XSS过滤
        const inputElements = document.querySelectorAll('input, textarea');
        inputElements.forEach(element => {
            element.addEventListener('input', (e) => {
                e.target.value = this.sanitizeInput(e.target.value);
            });
        });
    },
    
    // 清理输入
    sanitizeInput: function(input) {
        const div = document.createElement('div');
        div.textContent = input;
        return div.innerHTML;
    },
    
    // 清理HTML
    sanitizeHTML: function(html) {
        const temp = document.createElement('div');
        temp.innerHTML = html;
        return temp.textContent || temp.innerText || '';
    },
    
    // 初始化CSRF防护
    initCSRFProtection: function() {
        // 生成CSRF令牌
        this.generateCSRFToken();
        
        // 为所有表单添加CSRF令牌
        this.addCSRFTokenToForms();
    },
    
    // 生成CSRF令牌
    generateCSRFToken: function() {
        // 检查是否已经存在CSRF令牌
        let token = localStorage.getItem('csrf_token');
        
        if (!token) {
            // 生成新的CSRF令牌
            token = this.generateRandomToken();
            localStorage.setItem('csrf_token', token);
        }
        
        return token;
    },
    
    // 生成随机令牌
    generateRandomToken: function() {
        return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
    },
    
    // 为表单添加CSRF令牌
    addCSRFTokenToForms: function() {
        const forms = document.querySelectorAll('form');
        forms.forEach(form => {
            // 检查是否已经存在CSRF令牌输入
            if (!form.querySelector('input[name="csrf_token"]')) {
                const tokenInput = document.createElement('input');
                tokenInput.type = 'hidden';
                tokenInput.name = 'csrf_token';
                tokenInput.value = this.generateCSRFToken();
                form.appendChild(tokenInput);
            }
        });
    },
    
    // 初始化安全存储
    initSecureStorage: function() {
        // 这里可以添加安全存储相关的功能
        // 例如：加密存储敏感数据
    },
    
    // 初始化内容安全策略
    initContentSecurityPolicy: function() {
        // 这里可以添加内容安全策略相关的功能
    },
    
    // 安全地存储数据到本地存储
    secureLocalStorage: {
        // 存储数据
        set: function(key, value) {
            try {
                const serializedValue = JSON.stringify(value);
                localStorage.setItem(key, serializedValue);
                return true;
            } catch (error) {
                console.error('Error storing data:', error);
                return false;
            }
        },
        
        // 获取数据
        get: function(key) {
            try {
                const serializedValue = localStorage.getItem(key);
                if (serializedValue === null) {
                    return null;
                }
                return JSON.parse(serializedValue);
            } catch (error) {
                console.error('Error retrieving data:', error);
                return null;
            }
        },
        
        // 删除数据
        remove: function(key) {
            try {
                localStorage.removeItem(key);
                return true;
            } catch (error) {
                console.error('Error removing data:', error);
                return false;
            }
        },
        
        // 清除所有数据
        clear: function() {
            try {
                localStorage.clear();
                return true;
            } catch (error) {
                console.error('Error clearing data:', error);
                return false;
            }
        }
    }
};

// 导出安全模块
if (typeof module !== 'undefined' && module.exports) {
    module.exports = SecurityModule;
} else {
    window.SecurityModule = SecurityModule;
}
