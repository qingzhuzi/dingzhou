/**
 * 模块初始化文件
 * 导入并初始化所有模块
 */

// 导入模块
if (typeof require !== 'undefined') {
    // Node.js环境
    const CoreModule = require('./core');
    const ImageModule = require('./image');
    const UIModule = require('./ui');
    const LikeModule = require('./like');
} else {
    // 浏览器环境
    // 模块已经通过script标签加载到全局
}

// 初始化所有模块
function initAllModules() {
    console.log('Initializing all modules...');
    
    // 初始化核心模块
    if (typeof CoreModule !== 'undefined') {
        CoreModule.init();
    }
    
    console.log('All modules initialized');
}

// 导出初始化函数
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        initAllModules
    };
} else {
    window.initAllModules = initAllModules;
}
