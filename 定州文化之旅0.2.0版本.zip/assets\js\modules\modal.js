/**
 * 模态框模块
 * 统一管理详情弹窗
 */

const ModalModule = {
    // 保存滚动位置
    savedScrollPosition: { top: 0, left: 0 },

    // 显示景点详情
    showAttractionDetail: function(attractionId) {
        const attraction = window.AttractionData?.[attractionId];
        if (!attraction) {
            if (typeof showToast === 'function') showToast('景点信息加载失败');
            return;
        }

        const modal = document.getElementById('modal');
        const modalContent = document.getElementById('modalContent');
        
        if (!modal || !modalContent) return;
        
        // 保存当前滚动位置
        this.savedScrollPosition.top = window.pageYOffset || document.documentElement.scrollTop;
        this.savedScrollPosition.left = window.pageXOffset || document.documentElement.scrollLeft;
        localStorage.setItem('dingzhouScrollPosition', JSON.stringify(this.savedScrollPosition));

        // 生成内容
        modalContent.innerHTML = `
            <div class="relative">
                <div class="w-full h-48 rounded-xl mb-4 bg-cover bg-center" style="background-image: url('${attraction.image}')"></div>
                <button onclick="ModalModule.closeModal()" class="absolute top-4 right-4 bg-black/50 hover:bg-black/70 w-8 h-8 rounded-full flex items-center justify-center text-white transition-colors">
                    <i class="fa fa-times"></i>
                </button>
            </div>
            <h3 class="text-2xl font-bold text-white mb-2">${attraction.name}</h3>
            <div class="flex items-center text-white/70 text-sm mb-4">
                <i class="fa fa-map-marker mr-2"></i>
                <span>${attraction.location}</span>
                <span class="mx-2">|</span>
                <i class="fa fa-clock-o mr-2"></i>
                <span>${attraction.hours}</span>
            </div>
            <div class="space-y-4">
                <div>
                    <h4 class="font-semibold text-white mb-2">景点介绍</h4>
                    <p class="text-white/80 text-sm">${attraction.description}</p>
                </div>
                <div>
                    <h4 class="font-semibold text-white mb-2">历史渊源</h4>
                    <p class="text-white/80 text-sm">${attraction.history}</p>
                </div>
                <div>
                    <h4 class="font-semibold text-white mb-2">特色亮点</h4>
                    <ul class="list-disc list-inside text-white/80 text-sm space-y-1">
                        ${attraction.features.map(feature => `<li>${feature}</li>`).join('')}
                    </ul>
                </div>
            </div>
            <div class="mt-6 flex space-x-3">
                <button class="gradient-btn text-white font-semibold py-2 px-4 rounded-full text-sm flex-1 flex items-center justify-center like-button" data-like-type="attraction" data-like-id="${attractionId}">
                    <i class="fa fa-heart-o mr-2"></i>点赞
                </button>
                <button class="bg-white/20 hover:bg-white/30 text-white font-semibold py-2 px-4 rounded-full text-sm flex-1 flex items-center justify-center transition-colors">
                    <i class="fa fa-map-o mr-2"></i>导航
                </button>
            </div>
        `;
        
        modal.classList.remove('hidden');
        document.body.style.overflow = 'hidden';
        
        // 初始化点赞按钮
        setTimeout(() => {
            if (typeof updateLikeButtons === 'function') {
                updateLikeButtons();
            }
        }, 100);
    },

    // 显示美食详情
    showFoodDetail: function(foodId) {
        const food = window.FoodData?.[foodId];
        if (!food) {
            if (typeof showToast === 'function') showToast('美食信息加载失败');
            return;
        }

        const modal = document.getElementById('modal');
        const modalContent = document.getElementById('modalContent');
        
        if (!modal || !modalContent) return;

        modalContent.innerHTML = `
            <div class="relative">
                <div class="w-full h-48 rounded-xl mb-4 bg-cover bg-center" style="background-image: url('${food.image}')"></div>
                <button onclick="ModalModule.closeModal()" class="absolute top-4 right-4 bg-black/50 hover:bg-black/70 w-8 h-8 rounded-full flex items-center justify-center text-white transition-colors">
                    <i class="fa fa-times"></i>
                </button>
            </div>
            <h3 class="text-2xl font-bold text-white mb-2">${food.name}</h3>
            <div class="flex items-center text-white/70 text-sm mb-4">
                <i class="fa fa-map-marker mr-2"></i>
                <span>${food.location}</span>
                <span class="mx-2">|</span>
                <i class="fa fa-clock-o mr-2"></i>
                <span>${food.hours}</span>
            </div>
            <div class="space-y-4">
                <div>
                    <h4 class="font-semibold text-white mb-2">美食介绍</h4>
                    <p class="text-white/80 text-sm">${food.description}</p>
                </div>
                <div>
                    <h4 class="font-semibold text-white mb-2">历史渊源</h4>
                    <p class="text-white/80 text-sm">${food.history}</p>
                </div>
                <div>
                    <h4 class="font-semibold text-white mb-2">推荐理由</h4>
                    <ul class="list-disc list-inside text-white/80 text-sm space-y-1">
                        ${food.reasons.map(reason => `<li>${reason}</li>`).join('')}
                    </ul>
                </div>
            </div>
            <div class="mt-6 flex space-x-3">
                <button class="gradient-btn text-white font-semibold py-2 px-4 rounded-full text-sm flex-1 flex items-center justify-center like-button" data-like-type="food" data-like-id="${foodId}">
                    <i class="fa fa-heart-o mr-2"></i>点赞
                </button>
                <button class="bg-white/20 hover:bg-white/30 text-white font-semibold py-2 px-4 rounded-full text-sm flex-1 flex items-center justify-center transition-colors">
                    <i class="fa fa-share-alt mr-2"></i>分享
                </button>
            </div>
        `;
        
        modal.classList.remove('hidden');
        document.body.style.overflow = 'hidden';
        
        setTimeout(() => {
            if (typeof updateLikeButtons === 'function') {
                updateLikeButtons();
            }
        }, 100);
    },

    // 显示年俗详情
    showCustomDetail: function(customId) {
        const custom = window.CustomData?.[customId];
        if (!custom) {
            if (typeof showToast === 'function') showToast('年俗信息加载失败');
            return;
        }

        const modal = document.getElementById('modal');
        const modalContent = document.getElementById('modalContent');
        
        if (!modal || !modalContent) return;

        modalContent.innerHTML = `
            <div class="relative">
                <div class="w-full h-48 rounded-xl mb-4 bg-cover bg-center" style="background-image: url('${custom.image}')"></div>
                <button onclick="ModalModule.closeModal()" class="absolute top-4 right-4 bg-black/50 hover:bg-black/70 w-8 h-8 rounded-full flex items-center justify-center text-white transition-colors">
                    <i class="fa fa-times"></i>
                </button>
            </div>
            <h3 class="text-2xl font-bold text-white mb-2">${custom.name}</h3>
            <div class="flex items-center text-white/70 text-sm mb-4">
                <i class="fa fa-calendar mr-2"></i>
                <span>${custom.date}</span>
            </div>
            <div class="space-y-4">
                <div>
                    <h4 class="font-semibold text-white mb-2">活动介绍</h4>
                    <p class="text-white/80 text-sm">${custom.description}</p>
                </div>
                <div>
                    <h4 class="font-semibold text-white mb-2">历史渊源</h4>
                    <p class="text-white/80 text-sm">${custom.history}</p>
                </div>
                <div>
                    <h4 class="font-semibold text-white mb-2">活动内容</h4>
                    <ul class="list-disc list-inside text-white/80 text-sm space-y-1">
                        ${custom.activities.map(activity => `<li>${activity}</li>`).join('')}
                    </ul>
                </div>
            </div>
            <div class="mt-6 flex space-x-3">
                <button class="gradient-btn text-white font-semibold py-2 px-4 rounded-full text-sm flex-1 flex items-center justify-center like-button" data-like-type="custom" data-like-id="${customId}">
                    <i class="fa fa-heart-o mr-2"></i>点赞
                </button>
                <button class="bg-white/20 hover:bg-white/30 text-white font-semibold py-2 px-4 rounded-full text-sm flex-1 flex items-center justify-center transition-colors">
                    <i class="fa fa-share-alt mr-2"></i>分享
                </button>
            </div>
        `;
        
        modal.classList.remove('hidden');
        document.body.style.overflow = 'hidden';
        
        setTimeout(() => {
            if (typeof updateLikeButtons === 'function') {
                updateLikeButtons();
            }
        }, 100);
    },

    // 关闭模态框
    closeModal: function() {
        const modal = document.getElementById('modal');
        if (!modal) return;
        
        modal.classList.add('hidden');
        document.body.style.overflow = '';
    }
};

// 导出模块
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ModalModule;
} else {
    window.ModalModule = ModalModule;
    
    // 为了兼容性，保留全局函数
    window.showAttractionDetail = ModalModule.showAttractionDetail.bind(ModalModule);
    window.showFoodDetail = ModalModule.showFoodDetail.bind(ModalModule);
    window.showCustomDetail = ModalModule.showCustomDetail.bind(ModalModule);
    window.closeModal = ModalModule.closeModal.bind(ModalModule);
}
