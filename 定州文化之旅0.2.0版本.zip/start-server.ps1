Write-Host "========================================"
Write-Host "启动定州文化之旅服务器"
Write-Host "========================================"

Set-Location "D:\0\dingzhou-content"

while ($true) {
    Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] 启动服务器..."
    node server.js
    Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] 服务器已退出，5秒后重启..."
    Start-Sleep -Seconds 5
}
