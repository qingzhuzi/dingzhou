/**
 * 错误处理模块
 * 全局错误捕获和处理
 */

const ErrorHandler = {
    // 是否已初始化
    initialized: false,

    // 错误日志
    logs: [],

    // 最大日志数量
    maxLogs: 50,

    /**
     * 初始化错误处理
     */
    init: function() {
        if (this.initialized) return;

        // 全局错误捕获
        window.onerror = (message, source, lineno, colno, error) => {
            this.handleError({
                type: 'javascript',
                message: message,
                source: source,
                lineno: lineno,
                colno: colno,
                error: error?.stack || 'No stack trace',
                timestamp: new Date().toISOString()
            });
            return false; // 返回false让错误继续传播
        };

        // 未处理的Promise错误
        window.addEventListener('unhandledrejection', (event) => {
            this.handleError({
                type: 'promise',
                message: event.reason?.message || 'Unhandled Promise Rejection',
                error: event.reason?.stack || String(event.reason),
                timestamp: new Date().toISOString()
            });
        });

        // 资源加载错误
        window.addEventListener('error', (event) => {
            if (event.target && (event.target.tagName === 'IMG' || event.target.tagName === 'SCRIPT' || event.target.tagName === 'LINK')) {
                this.handleError({
                    type: 'resource',
                    message: `Failed to load ${event.target.tagName}`,
                    source: event.target.src || event.target.href,
                    timestamp: new Date().toISOString()
                });
            }
        }, true);

        this.initialized = true;
        console.log('Error handler initialized');
    },

    /**
     * 处理错误
     * @param {Object} errorInfo - 错误信息
     */
    handleError: function(errorInfo) {
        // 添加到日志
        this.logs.push(errorInfo);
        
        // 限制日志数量
        if (this.logs.length > this.maxLogs) {
            this.logs.shift();
        }

        // 保存到本地存储
        this.saveLogs();

        // 控制台输出
        console.error('[ErrorHandler]', errorInfo);

        // 显示用户友好的错误提示（只在严重错误时显示）
        if (this.isSeriousError(errorInfo)) {
            this.showUserFriendlyError(errorInfo);
        }

        // 可以在这里添加错误上报逻辑
        // this.reportError(errorInfo);
    },

    /**
     * 判断是否为严重错误
     * @param {Object} errorInfo - 错误信息
     * @returns {boolean}
     */
    isSeriousError: function(errorInfo) {
        // 资源加载错误通常是严重的
        if (errorInfo.type === 'resource') return true;
        
        // 某些特定错误
        const seriousPatterns = [
            'QuotaExceededError',
            'SecurityError',
            'NetworkError'
        ];
        
        return seriousPatterns.some(pattern => 
            errorInfo.message?.includes(pattern) || 
            errorInfo.error?.includes(pattern)
        );
    },

    /**
     * 显示用户友好的错误提示
     * @param {Object} errorInfo - 错误信息
     */
    showUserFriendlyError: function(errorInfo) {
        const messages = {
            resource: '部分资源加载失败，请检查网络连接',
            promise: '操作执行失败，请稍后重试',
            javascript: '页面出现错误，建议刷新页面',
            storage: '存储空间不足，请清理浏览器缓存',
            network: '网络连接失败，请检查网络设置'
        };

        const message = messages[errorInfo.type] || '发生未知错误，请刷新页面重试';
        
        if (typeof showToast === 'function') {
            showToast(message);
        } else {
            alert(message);
        }
    },

    /**
     * 保存日志到本地存储
     */
    saveLogs: function() {
        try {
            if (window.Storage) {
                Storage.set('error_logs', this.logs);
            } else {
                localStorage.setItem('dingzhouTravel_error_logs', JSON.stringify(this.logs));
            }
        } catch (e) {
            console.error('保存错误日志失败:', e);
        }
    },

    /**
     * 加载日志
     */
    loadLogs: function() {
        try {
            let logs;
            if (window.Storage) {
                logs = Storage.get('error_logs', []);
            } else {
                const saved = localStorage.getItem('dingzhouTravel_error_logs');
                logs = saved ? JSON.parse(saved) : [];
            }
            this.logs = logs;
        } catch (e) {
            console.error('加载错误日志失败:', e);
            this.logs = [];
        }
    },

    /**
     * 获取所有日志
     * @returns {Array} 错误日志
     */
    getLogs: function() {
        return this.logs;
    },

    /**
     * 清空日志
     */
    clearLogs: function() {
        this.logs = [];
        this.saveLogs();
    },

    /**
     * 包装函数，添加错误处理
     * @param {Function} fn - 要包装的函数
     * @param {string} context - 上下文信息
     * @returns {Function} 包装后的函数
     */
    wrap: function(fn, context = '') {
        return (...args) => {
            try {
                return fn.apply(this, args);
            } catch (error) {
                this.handleError({
                    type: 'javascript',
                    message: error.message,
                    context: context,
                    error: error.stack,
                    timestamp: new Date().toISOString()
                });
                throw error;
            }
        };
    },

    /**
     * 包装异步函数
     * @param {Function} fn - 要包装的异步函数
     * @param {string} context - 上下文信息
     * @returns {Function} 包装后的函数
     */
    wrapAsync: function(fn, context = '') {
        return async (...args) => {
            try {
                return await fn.apply(this, args);
            } catch (error) {
                this.handleError({
                    type: 'promise',
                    message: error.message,
                    context: context,
                    error: error.stack,
                    timestamp: new Date().toISOString()
                });
                throw error;
            }
        };
    }
};

// 导出模块
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ErrorHandler;
} else {
    window.ErrorHandler = ErrorHandler;
}
