/**
 * 点赞功能模块
 * 包含点赞管理、本地存储等功能
 */

// 点赞功能模块
const LikeModule = {
    // 初始化点赞功能
    init: function() {
        console.log('Like module initialized');
        this.initEventListeners();
        this.initLikeStatus();
    },
    
    // 初始化事件监听器
    initEventListeners: function() {
        document.querySelectorAll('.like-button').forEach(button => {
            button.addEventListener('click', (e) => {
                e.preventDefault();
                const likeType = button.dataset.likeType;
                const likeId = button.dataset.likeId;
                this.toggleLike(likeId, likeType);
            });
        });
    },
    
    // 初始化点赞状态
    initLikeStatus: function() {
        const likes = this.getLikes();
        document.querySelectorAll('[data-like-id]').forEach(btn => {
            const id = btn.getAttribute('data-like-id');
            if (likes[id]) {
                const icon = btn.querySelector('i');
                if (icon) {
                    icon.classList.remove('fa-heart-o');
                    icon.classList.add('fa-heart');
                    icon.classList.add('text-danger');
                }
            }
        });
    },
    
    // 切换点赞状态
    toggleLike: function(id, type) {
        const likes = this.getLikes();
        
        if (likes[id]) {
            delete likes[id];
            this.updateUI(id, false);
            this.showToast('已取消点赞');
        } else {
            likes[id] = {
                type: type,
                timestamp: Date.now()
            };
            this.updateUI(id, true);
            this.showToast('点赞成功');
        }
        
        this.saveLikes(likes);
    },
    
    // 更新UI
    updateUI: function(id, isLiked) {
        const likeBtn = document.querySelector(`[data-like-id="${id}"]`);
        if (likeBtn) {
            const icon = likeBtn.querySelector('i');
            if (icon) {
                if (isLiked) {
                    icon.classList.remove('fa-heart-o');
                    icon.classList.add('fa-heart');
                    icon.classList.add('text-danger');
                } else {
                    icon.classList.remove('fa-heart');
                    icon.classList.remove('text-danger');
                    icon.classList.add('fa-heart-o');
                }
            }
        }
    },
    
    // 获取点赞数据
    getLikes: function() {
        return JSON.parse(localStorage.getItem('likes')) || {};
    },
    
    // 保存点赞数据
    saveLikes: function(likes) {
        localStorage.setItem('likes', JSON.stringify(likes));
    },
    
    // 检查是否已点赞
    isLiked: function(id) {
        const likes = this.getLikes();
        return !!likes[id];
    },
    
    // 获取排序后的点赞
    getSortedLikes: function() {
        const likes = this.getLikes();
        return Object.entries(likes)
            .map(([id, data]) => ({ id, ...data }))
            .sort((a, b) => b.timestamp - a.timestamp);
    },
    
    // 显示提示信息
    showToast: function(message) {
        // 创建提示元素
        const toast = document.createElement('div');
        toast.className = 'fixed top-20 left-1/2 transform -translate-x-1/2 bg-black/80 text-white px-4 py-2 rounded-lg z-50';
        toast.textContent = message;
        
        // 添加到页面
        document.body.appendChild(toast);
        
        // 2秒后移除
        setTimeout(() => {
            toast.classList.add('opacity-0', 'transition-opacity', 'duration-300');
            setTimeout(() => {
                document.body.removeChild(toast);
            }, 300);
        }, 2000);
    }
};

// 导出点赞模块
if (typeof module !== 'undefined' && module.exports) {
    module.exports = LikeModule;
} else {
    window.LikeModule = LikeModule;
}
