/**
 * 点赞模块
 * 封装点赞功能的完整实现
 */

const LikesModule = {
    // 存储键名
    STORAGE_KEY: 'dingzhouLikes',

    // 加载点赞数据
    loadLikes: function() {
        try {
            const saved = localStorage.getItem(this.STORAGE_KEY);
            return saved ? JSON.parse(saved) : {};
        } catch (e) {
            console.error('加载点赞数据失败:', e);
            return {};
        }
    },

    // 保存点赞数据
    saveLikes: function(likes) {
        try {
            localStorage.setItem(this.STORAGE_KEY, JSON.stringify(likes));
        } catch (e) {
            console.error('保存点赞数据失败:', e);
        }
    },

    // 切换点赞状态
    toggleLike: function(button) {
        const type = button.getAttribute('data-like-type');
        const id = button.getAttribute('data-like-id');
        
        if (!type || !id) {
            console.error('点赞按钮缺少必要属性');
            return;
        }
        
        const likes = this.loadLikes();
        const key = `${type}_${id}`;
        const isLiked = !likes[key];
        likes[key] = isLiked;
        this.saveLikes(likes);
        
        // 更新按钮状态
        this.updateButtonState(button, isLiked);
        
        // 显示提示
        if (typeof showToast === 'function') {
            showToast(isLiked ? '点赞成功' : '已取消点赞');
        }
    },

    // 更新单个按钮状态
    updateButtonState: function(button, isLiked) {
        const icon = button.querySelector('i');
        if (!icon) return;
        
        if (isLiked) {
            icon.className = 'fa fa-heart text-red-500 mr-2';
            button.classList.add('liked');
        } else {
            icon.className = 'fa fa-heart-o text-white mr-2';
            button.classList.remove('liked');
        }
    },

    // 更新所有点赞按钮状态
    updateAllButtons: function() {
        const likes = this.loadLikes();
        
        document.querySelectorAll('.like-button').forEach(button => {
            const type = button.getAttribute('data-like-type');
            const id = button.getAttribute('data-like-id');
            
            if (type && id) {
                const key = `${type}_${id}`;
                this.updateButtonState(button, likes[key]);
            }
        });
    },

    // 检查是否已点赞
    isLiked: function(type, id) {
        const likes = this.loadLikes();
        return likes[`${type}_${id}`] || false;
    },

    // 初始化模块
    init: function() {
        // 绑定点击事件
        document.addEventListener('click', (e) => {
            const button = e.target.closest('.like-button');
            if (button) {
                e.preventDefault();
                e.stopPropagation();
                this.toggleLike(button);
            }
        });

        // 初始化按钮状态
        this.updateAllButtons();
        
        console.log('Likes module initialized');
    }
};

// 导出模块
if (typeof module !== 'undefined' && module.exports) {
    module.exports = LikesModule;
} else {
    window.LikesModule = LikesModule;
    
    // 为了兼容性，保留全局函数
    window.updateLikeButtons = LikesModule.updateAllButtons.bind(LikesModule);
}
