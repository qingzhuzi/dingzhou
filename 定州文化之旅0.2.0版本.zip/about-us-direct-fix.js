// 直接在页面上添加关于我们按钮和模态框
function addAboutUsButtonAndModal() {
    // 创建一个明显的测试按钮
    const testButton = document.createElement('button');
    testButton.id = 'testAboutButton';
    testButton.innerHTML = '<i class="fa fa-info-circle mr-2"></i>测试关于我们';
    testButton.className = 'fixed top-20 right-6 bg-red-500 hover:bg-red-600 text-white font-bold py-3 px-6 rounded-full z-50 shadow-lg animate-pulse';
    testButton.onclick = function() {
        alert('测试按钮点击成功！');
        showAboutModalFixed();
    };
    document.body.appendChild(testButton);

    // 创建关于我们模态框
    const aboutModalHTML = `
    <div id="aboutModalFixed" class="fixed inset-0 z-50 hidden items-center justify-center p-4">
        <div class="absolute inset-0 bg-black/70" onclick="hideAboutModalFixed()"></div>
        <div class="glass-card rounded-3xl p-6 sm:p-8 w-11/12 max-w-md relative z-10 animate-slide-up max-h-[80vh] overflow-y-auto">
            <div class="flex justify-between items-center mb-6">
                <h3 class="text-xl font-bold text-white">关于我们</h3>
                <button class="text-white hover:text-blue-300 transition-colors" onclick="hideAboutModalFixed()">
                    <i class="fa fa-times text-xl"></i>
                </button>
            </div>
            <div class="space-y-6">
                <div class="text-center">
                    <img src="https://p26-flow-imagex-sign.byteimg.com/tos-cn-i-a9rns2rl98/rc/pc/super_tool/6521157daf3c462fb8e63aa311d310a6~tplv-a9rns2rl98-image.image?lk3s=8e244e95&rcl=20260209145959E368B756F237651ABBDC&rrcfp=f06b921b&x-expires=1773212413&x-signature=61TvSPJ6DnSFt9kVYiH0Hs4iA%2F0%3D" alt="定州塔" class="w-24 h-24 object-cover rounded-full mx-auto mb-4">
                    <h4 class="text-lg font-bold text-white">定州文化之旅团队</h4>
                    <p class="text-white/60 text-sm">我们致力于传播定州千年文化，为您提供最优质的旅游服务。</p>
                </div>
                <div>
                    <h5 class="font-semibold text-white mb-2">功能亮点</h5>
                    <ul class="text-white/70 text-sm space-y-2">
                        <li class="flex items-start space-x-2">
                            <i class="fa fa-star text-yellow-400 mt-1"></i>
                            <span>精美的毛玻璃效果和iOS风格设计</span>
                        </li>
                        <li class="flex items-start space-x-2">
                            <i class="fa fa-map-marker text-red-400 mt-1"></i>
                            <span>详细的景点、美食、年俗介绍</span>
                        </li>
                        <li class="flex items-start space-x-2">
                            <i class="fa fa-lightbulb-o text-yellow-400 mt-1"></i>
                            <span>智能的AI路线规划</span>
                        </li>
                        <li class="flex items-start space-x-2">
                            <i class="fa fa-users text-blue-400 mt-1"></i>
                            <span>活跃的用户讨论社区</span>
                        </li>
                    </ul>
                </div>
                <div>
                    <h5 class="font-semibold text-white mb-2">技术支持</h5>
                    <p class="text-white/70 text-sm">本应用由顶尖的前端开发团队打造，采用了最新的Web技术，为您带来流畅的用户体验。</p>
                </div>
                <div>
                    <h5 class="font-semibold text-white mb-2">联系方式</h5>
                    <p class="text-white/70 text-sm flex items-center space-x-2">
                        <i class="fa fa-envelope"></i>
                        <span>contact@dingzhoutravel.com</span>
                    </p>
                    <p class="text-white/70 text-sm flex items-center space-x-2">
                        <i class="fa fa-phone"></i>
                        <span>400-123-4567</span>
                    </p>
                </div>
                <div class="text-center text-white/50 text-xs">
                    <p>© 2026 定州文化之旅. All Rights Reserved.</p>
                    <p>版本 1.0.0</p>
                </div>
            </div>
        </div>
    </div>
    `;
    
    const tempContainer = document.createElement('div');
    tempContainer.innerHTML = aboutModalHTML;
    document.body.appendChild(tempContainer.firstElementChild);

    // 添加CSS动画
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideUp {
            from { transform: translateY(100%); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
        .animate-slide-up {
            animation: slideUp 0.3s ease-out forwards;
        }
        .glass-card {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.1);
        }
    `;
    document.head.appendChild(style);
}

// 显示关于我们模态框
function showAboutModalFixed() {
    const modal = document.getElementById('aboutModalFixed');
    if (modal) {
        modal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    } else {
        alert('模态框创建失败，请刷新页面重试。');
    }
}

// 隐藏关于我们模态框
function hideAboutModalFixed() {
    const modal = document.getElementById('aboutModalFixed');
    if (modal) {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
}

// 修复侧边菜单中的关于我们按钮
function fixSideMenuAboutButton() {
    const aboutButtons = document.querySelectorAll('button span');
    aboutButtons.forEach(span => {
        if (span.textContent.trim() === '关于我们') {
            const button = span.closest('button');
            if (button) {
                button.onclick = function() {
                    showAboutModalFixed();
                };
                console.log('侧边菜单关于我们按钮已修复');
            }
        }
    });
}

// 页面加载完成后执行
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() {
        addAboutUsButtonAndModal();
        fixSideMenuAboutButton();
    });
} else {
    addAboutUsButtonAndModal();
    fixSideMenuAboutButton();
}

// 立即执行（如果页面已经加载完成）
setTimeout(function() {
    if (!document.getElementById('testAboutButton')) {
        addAboutUsButtonAndModal();
        fixSideMenuAboutButton();
    }
}, 1000);
