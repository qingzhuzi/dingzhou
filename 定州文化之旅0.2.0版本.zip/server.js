const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 5000;
const ROOT = 'd:/0/dingzhou-content';

console.log('========================================');
console.log('服务器启动中...');
console.log('========================================');

// 邮件配置
const EMAIL_CONFIG = {
    host: 'smtp.163.com',
    port: 465,
    user: 'qingzhuzi001@163.com',
    pass: 'WQqDAmCDHmvkwStx',
    to: 'qingzhuzi001@163.com'
};

// 加载 nodemailer
let transporter = null;
try {
    const nodemailerPath = path.join(ROOT, 'node_modules/nodemailer-8.0.1/package/lib/nodemailer.js');
    if (fs.existsSync(nodemailerPath)) {
        const nodemailer = require(nodemailerPath);
        transporter = nodemailer.createTransport({
            host: EMAIL_CONFIG.host,
            port: EMAIL_CONFIG.port,
            secure: true,
            auth: {
                user: EMAIL_CONFIG.user,
                pass: EMAIL_CONFIG.pass
            }
        });
        console.log('邮件服务已就绪');
    } else {
        console.log('nodemailer文件不存在');
    }
} catch (e) {
    console.log('邮件服务加载失败:', e.message);
}

const server = http.createServer((req, res) => {
    let url = req.url.split('?')[0];
    console.log('请求:', req.method, url);
    
    // CORS
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    
    if (req.method === 'OPTIONS') {
        res.writeHead(200);
        res.end();
        return;
    }
    
    // API: 提交反馈
    if (url === '/api/submit-feedback' && req.method === 'POST') {
        let body = '';
        req.on('data', chunk => body += chunk);
        req.on('end', () => {
            console.log('收到反馈请求');
            try {
                const feedback = JSON.parse(body);
                console.log('反馈内容:', feedback.content);
                
                // 保存
                const filePath = path.join(ROOT, 'feedbacks.json');
                let list = [];
                if (fs.existsSync(filePath)) {
                    try { list = JSON.parse(fs.readFileSync(filePath, 'utf8')); } catch(e) {}
                }
                list.push(feedback);
                fs.writeFileSync(filePath, JSON.stringify(list, null, 2));
                console.log('反馈已保存');
                
                // 发邮件
                if (transporter) {
                    const types = { suggestion: '功能建议', bug: '问题反馈', experience: '体验反馈', other: '其他' };
                    transporter.sendMail({
                        from: EMAIL_CONFIG.user,
                        to: EMAIL_CONFIG.to,
                        subject: '定州文化之旅 - 用户反馈',
                        text: `类型: ${types[feedback.type] || '未知'}\n内容: ${feedback.content}\n联系方式: ${feedback.contactInfo || '无'}\n时间: ${new Date().toLocaleString('zh-CN')}`
                    }, (err, info) => {
                        if (err) console.log('邮件发送失败:', err.message);
                        else console.log('邮件发送成功:', info.messageId);
                    });
                } else {
                    console.log('邮件服务不可用');
                }
                
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: true }));
            } catch (e) {
                console.log('处理错误:', e.message);
                res.writeHead(500, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: false, message: e.message }));
            }
        });
        return;
    }
    
    // 静态文件
    if (url === '/') url = '/index.html';
    const filePath = path.join(ROOT, url);
    const ext = path.extname(filePath);
    const types = {
        '.html': 'text/html; charset=utf-8',
        '.css': 'text/css; charset=utf-8',
        '.js': 'application/javascript; charset=utf-8',
        '.json': 'application/json; charset=utf-8',
        '.png': 'image/png',
        '.jpg': 'image/jpeg',
        '.svg': 'image/svg+xml',
        '.ico': 'image/x-icon'
    };
    
    fs.readFile(filePath, (err, data) => {
        if (err) {
            res.writeHead(404);
            res.end('Not Found');
            return;
        }
        res.writeHead(200, { 'Content-Type': types[ext] || 'text/plain' });
        res.end(data);
    });
});

server.on('error', err => console.log('服务器错误:', err.message));

server.listen(PORT, () => {
    console.log('服务器运行: http://localhost:' + PORT);
    console.log('========================================');
});
