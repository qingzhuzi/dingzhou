/**
 * 存储模块
 * 封装localStorage操作，添加错误处理和版本控制
 */

const Storage = {
    // 存储前缀，避免与其他应用冲突
    PREFIX: 'dingzhouTravel_',
    
    // 数据版本号，用于数据迁移
    VERSION: '1.0',

    /**
     * 获取存储项
     * @param {string} key - 键名
     * @param {*} defaultValue - 默认值
     * @returns {*} 存储的值或默认值
     */
    get: function(key, defaultValue = null) {
        try {
            const fullKey = this.PREFIX + key;
            const item = localStorage.getItem(fullKey);
            
            if (item === null) {
                return defaultValue;
            }
            
            const data = JSON.parse(item);
            
            // 检查数据版本
            if (data._version && data._version !== this.VERSION) {
                console.warn(`数据版本不匹配: ${key}`);
                // 这里可以添加数据迁移逻辑
            }
            
            return data.value;
        } catch (e) {
            console.error(`获取存储项失败 [${key}]:`, e);
            return defaultValue;
        }
    },

    /**
     * 设置存储项
     * @param {string} key - 键名
     * @param {*} value - 值
     * @returns {boolean} 是否成功
     */
    set: function(key, value) {
        try {
            const fullKey = this.PREFIX + key;
            const data = {
                _version: this.VERSION,
                _timestamp: new Date().toISOString(),
                value: value
            };
            
            localStorage.setItem(fullKey, JSON.stringify(data));
            return true;
        } catch (e) {
            console.error(`设置存储项失败 [${key}]:`, e);
            
            // 检查是否是存储空间不足
            if (e.name === 'QuotaExceededError') {
                console.warn('存储空间不足，尝试清理旧数据...');
                this.cleanup();
                
                // 重试一次
                try {
                    const fullKey = this.PREFIX + key;
                    const data = {
                        _version: this.VERSION,
                        _timestamp: new Date().toISOString(),
                        value: value
                    };
                    localStorage.setItem(fullKey, JSON.stringify(data));
                    return true;
                } catch (retryError) {
                    console.error('重试存储失败:', retryError);
                }
            }
            
            return false;
        }
    },

    /**
     * 移除存储项
     * @param {string} key - 键名
     * @returns {boolean} 是否成功
     */
    remove: function(key) {
        try {
            const fullKey = this.PREFIX + key;
            localStorage.removeItem(fullKey);
            return true;
        } catch (e) {
            console.error(`移除存储项失败 [${key}]:`, e);
            return false;
        }
    },

    /**
     * 清空所有存储
     * @returns {boolean} 是否成功
     */
    clear: function() {
        try {
            // 只清空本应用的数据
            Object.keys(localStorage)
                .filter(key => key.startsWith(this.PREFIX))
                .forEach(key => localStorage.removeItem(key));
            return true;
        } catch (e) {
            console.error('清空存储失败:', e);
            return false;
        }
    },

    /**
     * 获取所有存储项
     * @returns {Object} 所有存储项
     */
    getAll: function() {
        const result = {};
        try {
            Object.keys(localStorage)
                .filter(key => key.startsWith(this.PREFIX))
                .forEach(key => {
                    const shortKey = key.replace(this.PREFIX, '');
                    result[shortKey] = this.get(shortKey);
                });
        } catch (e) {
            console.error('获取所有存储项失败:', e);
        }
        return result;
    },

    /**
     * 获取存储使用情况
     * @returns {Object} 使用情况信息
     */
    getUsage: function() {
        try {
            let totalSize = 0;
            const items = {};
            
            Object.keys(localStorage)
                .filter(key => key.startsWith(this.PREFIX))
                .forEach(key => {
                    const size = localStorage.getItem(key).length * 2; // UTF-16编码，每个字符2字节
                    totalSize += size;
                    items[key] = {
                        size: size,
                        sizeKB: (size / 1024).toFixed(2) + ' KB'
                    };
                });
            
            // 估算总容量（通常为5MB或10MB）
            const estimatedQuota = 5 * 1024 * 1024; // 5MB
            const usedPercentage = (totalSize / estimatedQuota * 100).toFixed(2);
            
            return {
                totalSize: totalSize,
                totalSizeKB: (totalSize / 1024).toFixed(2) + ' KB',
                totalSizeMB: (totalSize / (1024 * 1024)).toFixed(2) + ' MB',
                estimatedQuota: estimatedQuota,
                usedPercentage: usedPercentage + '%',
                items: items
            };
        } catch (e) {
            console.error('获取存储使用情况失败:', e);
            return null;
        }
    },

    /**
     * 清理旧数据
     * @param {number} keepDays - 保留最近几天的数据
     */
    cleanup: function(keepDays = 30) {
        try {
            const now = new Date();
            const cutoffDate = new Date(now.getTime() - keepDays * 24 * 60 * 60 * 1000);
            
            Object.keys(localStorage)
                .filter(key => key.startsWith(this.PREFIX))
                .forEach(key => {
                    try {
                        const data = JSON.parse(localStorage.getItem(key));
                        if (data._timestamp) {
                            const itemDate = new Date(data._timestamp);
                            if (itemDate < cutoffDate) {
                                localStorage.removeItem(key);
                                console.log(`清理旧数据: ${key}`);
                            }
                        }
                    } catch (e) {
                        // 如果解析失败，删除该项
                        localStorage.removeItem(key);
                    }
                });
        } catch (e) {
            console.error('清理存储失败:', e);
        }
    },

    /**
     * 检查存储是否可用
     * @returns {boolean} 是否可用
     */
    isAvailable: function() {
        try {
            const testKey = this.PREFIX + '__test__';
            localStorage.setItem(testKey, 'test');
            localStorage.removeItem(testKey);
            return true;
        } catch (e) {
            return false;
        }
    }
};

// 导出模块
if (typeof module !== 'undefined' && module.exports) {
    module.exports = Storage;
} else {
    window.Storage = Storage;
}
