/**
 * 用户体验模块
 * 包含微交互、动画效果和用户操作反馈等功能
 */

// 用户体验模块
const UXModule = {
    // 初始化用户体验功能
    init: function() {
        console.log('UX module initialized');
        this.initScrollProgress();
        this.initSmoothTransitions();
        this.initInteractiveElements();
        this.initMicroAnimations();
    },
    
    // 初始化滚动进度指示器
    initScrollProgress: function() {
        // 创建滚动进度条
        const progressBar = document.createElement('div');
        progressBar.id = 'scroll-progress';
        progressBar.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            height: 3px;
            background: linear-gradient(90deg, #007AFF, #5856D6);
            z-index: 100;
            width: 0%;
            transition: width 0.1s ease;
        `;
        document.body.appendChild(progressBar);
        
        // 监听滚动事件
        window.addEventListener('scroll', function() {
            const winScroll = document.body.scrollTop || document.documentElement.scrollTop;
            const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
            const scrolled = (winScroll / height) * 100;
            progressBar.style.width = scrolled + '%';
        });
    },
    
    // 初始化平滑过渡效果
    initSmoothTransitions: function() {
        // 为所有页面元素添加淡入效果
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, observerOptions);
        
        // 观察所有需要动画的元素 - 不再设置初始opacity为0，避免闪烁
        document.querySelectorAll('.animate-on-scroll').forEach(el => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(20px)';
            el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
            observer.observe(el);
        });
    },
    
    // 初始化交互式元素
    initInteractiveElements: function() {
        // 增强按钮交互
        this.enhanceButtons();
        
        // 增强卡片交互
        this.enhanceCards();
        
        // 增强输入框交互
        this.enhanceInputs();
    },
    
    // 增强按钮交互
    enhanceButtons: function() {
        document.querySelectorAll('button, .gradient-btn, [type="button"], [type="submit"]').forEach(button => {
            // 添加悬停效果
            button.style.transition = 'all 0.3s ease';
            
            // 添加点击反馈
            button.addEventListener('click', function(e) {
                const ripple = document.createElement('span');
                const rect = this.getBoundingClientRect();
                const size = Math.max(rect.width, rect.height);
                const x = e.clientX - rect.left - size / 2;
                const y = e.clientY - rect.top - size / 2;
                
                ripple.style.cssText = `
                    position: absolute;
                    width: ${size}px;
                    height: ${size}px;
                    left: ${x}px;
                    top: ${y}px;
                    background: rgba(255, 255, 255, 0.3);
                    border-radius: 50%;
                    transform: scale(0);
                    animation: ripple 0.6s linear;
                    pointer-events: none;
                    z-index: 1;
                `;
                
                // 确保按钮有相对定位
                if (window.getComputedStyle(this).position === 'static') {
                    this.style.position = 'relative';
                    this.style.overflow = 'hidden';
                }
                
                this.appendChild(ripple);
                
                setTimeout(() => {
                    ripple.remove();
                }, 600);
            });
        });
        
        // 添加 ripple 动画
        const style = document.createElement('style');
        style.textContent = `
            @keyframes ripple {
                to {
                    transform: scale(4);
                    opacity: 0;
                }
            }
        `;
        document.head.appendChild(style);
    },
    
    // 增强卡片交互
    enhanceCards: function() {
        document.querySelectorAll('.glass-card, .glass-card-hover').forEach(card => {
            // 添加鼠标悬停效果
            card.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-4px) scale(1.01)';
                this.style.boxShadow = '0 12px 40px rgba(0, 0, 0, 0.2)';
            });
            
            card.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0) scale(1)';
                this.style.boxShadow = '0 8px 32px rgba(0, 0, 0, 0.1)';
            });
        });
    },
    
    // 增强输入框交互
    enhanceInputs: function() {
        document.querySelectorAll('input, textarea').forEach(input => {
            input.addEventListener('focus', function() {
                this.style.transform = 'scale(1.02)';
                this.style.boxShadow = '0 0 0 3px rgba(0, 122, 255, 0.3)';
            });
            
            input.addEventListener('blur', function() {
                this.style.transform = 'scale(1)';
                this.style.boxShadow = 'none';
            });
        });
    },
    
    // 初始化微动画
    initMicroAnimations: function() {
        // 添加页面加载动画
        this.initPageLoadAnimation();
        
        // 添加滚动触发的动画
        this.initScrollAnimations();
        
        // 添加背景粒子效果
        this.initBackgroundParticles();
    },
    
    // 初始化页面加载动画
    initPageLoadAnimation: function() {
        // 这里可以添加更复杂的页面加载动画
    },
    
    // 初始化滚动触发的动画
    initScrollAnimations: function() {
        // 监听滚动事件，添加视差效果
        window.addEventListener('scroll', function() {
            const scrolled = window.pageYOffset;
            const parallaxElements = document.querySelectorAll('.parallax-bg');
            
            parallaxElements.forEach(element => {
                const speed = element.dataset.speed || 0.5;
                element.style.transform = `translateY(${scrolled * speed}px)`;
            });
        });
    },
    
    // 初始化背景粒子效果
    initBackgroundParticles: function() {
        // 创建粒子容器
        const particlesContainer = document.createElement('div');
        particlesContainer.id = 'particles-container';
        particlesContainer.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: -1;
        `;
        document.body.appendChild(particlesContainer);
        
        // 创建粒子
        const particleCount = 20;
        for (let i = 0; i < particleCount; i++) {
            const particle = document.createElement('div');
            const size = Math.random() * 10 + 5;
            const x = Math.random() * 100;
            const y = Math.random() * 100;
            const duration = Math.random() * 20 + 10;
            const delay = Math.random() * 5;
            
            particle.style.cssText = `
                position: absolute;
                width: ${size}px;
                height: ${size}px;
                background: rgba(255, 255, 255, ${Math.random() * 0.3 + 0.1});
                border-radius: 50%;
                left: ${x}%;
                top: ${y}%;
                animation: float ${duration}s ease-in-out ${delay}s infinite;
            `;
            
            particlesContainer.appendChild(particle);
        }
        
        // 添加浮动动画
        const style = document.createElement('style');
        style.textContent = `
            @keyframes float {
                0%, 100% {
                    transform: translateY(0px) rotate(0deg);
                    opacity: 0.1;
                }
                50% {
                    transform: translateY(-50px) rotate(180deg);
                    opacity: 0.3;
                }
            }
        `;
        document.head.appendChild(style);
    },
    
    // 显示通知
    showNotification: function(message, type = 'info', duration = 3000) {
        const notification = document.createElement('div');
        const types = {
            info: 'bg-blue-500',
            success: 'bg-green-500',
            error: 'bg-red-500',
            warning: 'bg-yellow-500'
        };
        
        notification.className = `fixed top-20 right-6 ${types[type] || types.info} text-white px-6 py-3 rounded-lg shadow-lg z-50 glass-card transform translate-x-full transition-transform duration-300 ease-out`;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        // 显示通知
        setTimeout(() => {
            notification.style.transform = 'translateX(0)';
        }, 100);
        
        // 自动隐藏
        setTimeout(() => {
            notification.style.transform = 'translateX(full)';
            setTimeout(() => {
                notification.remove();
            }, 300);
        }, duration);
    }
};

// 导出UX模块
if (typeof module !== 'undefined' && module.exports) {
    module.exports = UXModule;
} else {
    window.UXModule = UXModule;
}
