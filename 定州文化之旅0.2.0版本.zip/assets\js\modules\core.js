/**
 * 核心功能模块
 * 包含网站的核心功能和初始化逻辑
 */

// 核心模块对象
const CoreModule = {
    // 初始化核心功能
    init: function() {
        console.log('Core module initialized');
        this.initAOS();
        this.initEventListeners();
    },
    
    // 初始化AOS动画库
    initAOS: function() {
        if (typeof AOS !== 'undefined') {
            AOS.init({
                duration: 800,
                easing: 'ease-in-out',
                once: true,
                offset: 100
            });
        }
    },
    
    // 初始化事件监听器
    initEventListeners: function() {
        // 页面加载完成后的初始化
        document.addEventListener('DOMContentLoaded', function() {
            // 初始化其他模块
            ImageModule.init();
            UIModule.init();
            LikeModule.init();
            if (typeof UXModule !== 'undefined') {
                UXModule.init();
            }
            if (typeof DarkModeModule !== 'undefined') {
                DarkModeModule.init();
            }
            if (typeof ResponsiveModule !== 'undefined') {
                ResponsiveModule.init();
            }
            if (typeof SecurityModule !== 'undefined') {
                SecurityModule.init();
            }
            
            // 更新未读消息数量
            CoreModule.updateUnreadCount();
        });
    },
    
    // 更新未读消息数量
    updateUnreadCount: function() {
        // 模拟更新未读消息数量
        console.log('Unread count updated');
    },
    
    // 显示提示信息
    showToast: function(message, duration = 3000) {
        // 创建提示元素
        const toast = document.createElement('div');
        toast.className = 'fixed bottom-6 left-1/2 transform -translate-x-1/2 bg-black/80 text-white px-4 py-2 rounded-lg z-50 glass-card';
        toast.textContent = message;
        
        // 添加到页面
        document.body.appendChild(toast);
        
        // 显示动画
        toast.style.opacity = '0';
        toast.style.transition = 'opacity 0.3s ease-out';
        setTimeout(function() {
            toast.style.opacity = '1';
        }, 100);
        
        // 自动隐藏
        setTimeout(function() {
            toast.style.opacity = '0';
            setTimeout(function() {
                if (document.body.contains(toast)) {
                    document.body.removeChild(toast);
                }
            }, 300);
        }, duration);
    }
};

// 导出核心模块
if (typeof module !== 'undefined' && module.exports) {
    module.exports = CoreModule;
} else {
    window.CoreModule = CoreModule;
}
