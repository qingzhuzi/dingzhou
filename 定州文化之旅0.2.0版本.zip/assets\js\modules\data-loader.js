/**
 * 数据加载器模块
 * 从JSON文件加载数据
 */

const DataLoader = {
    // 数据缓存
    cache: {},

    /**
     * 加载JSON数据
     * @param {string} url - JSON文件URL
     * @param {boolean} useCache - 是否使用缓存
     * @returns {Promise<Object>} 数据对象
     */
    load: async function(url, useCache = true) {
        // 检查缓存
        if (useCache && this.cache[url]) {
            return this.cache[url];
        }

        try {
            const response = await fetch(url);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const data = await response.json();
            
            // 缓存数据
            if (useCache) {
                this.cache[url] = data;
            }
            
            return data;
        } catch (error) {
            console.error(`加载数据失败 [${url}]:`, error);
            // 返回空对象作为降级
            return {};
        }
    },

    /**
     * 加载所有数据
     * @returns {Promise<Object>} 所有数据
     */
    loadAll: async function() {
        try {
            const [attractions, foods, customs] = await Promise.all([
                this.load('data/attractions.json'),
                this.load('data/foods.json'),
                this.load('data/customs.json')
            ]);

            // 挂载到全局
            window.AttractionData = attractions;
            window.FoodData = foods;
            window.CustomData = customs;

            return { attractions, foods, customs };
        } catch (error) {
            console.error('加载所有数据失败:', error);
            // 使用内置数据作为降级
            this.useFallbackData();
            return {
                attractions: window.AttractionData || {},
                foods: window.FoodData || {},
                customs: window.CustomData || {}
            };
        }
    },

    /**
     * 使用内置数据作为降级
     */
    useFallbackData: function() {
        // 如果全局数据不存在，使用内置数据
        if (!window.AttractionData) {
            window.AttractionData = this.getFallbackAttractions();
        }
        if (!window.FoodData) {
            window.FoodData = this.getFallbackFoods();
        }
        if (!window.CustomData) {
            window.CustomData = this.getFallbackCustoms();
        }
    },

    /**
     * 获取景点降级数据
     */
    getFallbackAttractions: function() {
        return {
            kaiyuanPagoda: {
                name: '开元寺塔',
                image: 'https://p11-doubao-search-sign.byteimg.com/tos-cn-i-be4g95zd3a/1402933981981573125~tplv-be4g95zd3a-image.jpeg',
                location: '定州市区',
                hours: '08:00 - 17:30',
                description: '始建于北宋，是中国现存最高的砖木结构古塔之一。',
                history: '开元寺塔始建于北宋咸平四年（1001年）。',
                features: ['中国现存最高的砖木结构古塔之一'],
                rating: 4.5
            },
            confucianTemple: {
                name: '定州文庙',
                image: 'https://p3-doubao-search-sign.byteimg.com/labis/98566255725b9c412e6a830b9296c6ab~tplv-be4g95zd3a-image.jpeg',
                location: '定州市区',
                hours: '09:00 - 17:00',
                description: '河北省重点文物保护单位，始建于唐代。',
                history: '定州文庙始建于唐大中二年（848年）。',
                features: ['中国北方保存最为完整的文庙之一'],
                rating: 4.2
            }
        };
    },

    /**
     * 获取美食降级数据
     */
    getFallbackFoods: function() {
        return {
            dingzhouChicken: {
                name: '定州烧鸡',
                image: 'https://p26-doubao-search-sign.byteimg.com/labis/28735074eaa6fa9e786fca41e5ab9690~tplv-be4g95zd3a-image.jpeg',
                location: '定州市区各大餐馆',
                hours: '10:00 - 22:00',
                description: '定州传统特色小吃，皮脆肉嫩。',
                history: '定州烧鸡历史悠久，据传起源于清代。',
                reasons: ['选用本地散养土鸡', '传统制作工艺'],
                rating: 4.5
            },
            dongpoPork: {
                name: '北派东坡肘子',
                image: 'https://p11-doubao-search-sign.byteimg.com/pgc-image/5696895b24fe4a3d8cfcce069876a03e~tplv-be4g95zd3a-image.jpeg',
                location: '定州市区各大餐馆',
                hours: '11:00 - 21:00',
                description: '定州传统名菜，香而不腻。',
                history: '北派东坡肘子始创于北宋年间。',
                reasons: ['历史悠久', '香而不腻'],
                rating: 4.6
            }
        };
    },

    /**
     * 获取年俗降级数据
     */
    getFallbackCustoms: function() {
        return {
            lanternFestival: {
                name: '正月十五闹元宵',
                image: 'https://p26-doubao-search-sign.byteimg.com/tos-cn-i-xv4ileqgde/0b5a21a13230492e87b663f5dc3b0d4e~tplv-be4g95zd3a-image.jpeg',
                date: '农历正月十五',
                description: '定州传统民俗活动，包括舞龙灯等。',
                history: '正月十五闹元宵是定州传统的民俗活动。',
                activities: ['舞龙灯表演', '踩高跷比赛']
            }
        };
    },

    /**
     * 清除缓存
     */
    clearCache: function() {
        this.cache = {};
    }
};

// 导出模块
if (typeof module !== 'undefined' && module.exports) {
    module.exports = DataLoader;
} else {
    window.DataLoader = DataLoader;
}
