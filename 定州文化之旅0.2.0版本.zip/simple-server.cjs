const http = require('http');
const fs = require('fs');
const path = require('path');

const server = http.createServer((req, res) => {
    console.log('Request:', req.url);
    
    let filePath = req.url;
    if (filePath === '/') filePath = '/index.html';
    
    // Remove query string
    filePath = filePath.split('?')[0];
    
    // Security: prevent directory traversal
    if (filePath.includes('..')) {
        res.writeHead(403);
        res.end('Forbidden');
        return;
    }
    
    const fullPath = path.join(__dirname, filePath);
    console.log('Full path:', fullPath);
    
    const extname = path.extname(filePath).toLowerCase();
    const mimeTypes = {
        '.html': 'text/html',
        '.js': 'text/javascript',
        '.css': 'text/css',
        '.json': 'application/json',
        '.png': 'image/png',
        '.jpg': 'image/jpeg',
        '.jpeg': 'image/jpeg',
        '.gif': 'image/gif',
        '.svg': 'image/svg+xml',
        '.ico': 'image/x-icon'
    };
    
    // Check if path is a directory
    fs.stat(fullPath, (err, stats) => {
        if (err) {
            console.error('Stat error:', err.code);
            res.writeHead(404, { 'Content-Type': 'text/html' });
            res.end('<h1>404 Not Found</h1>');
            return;
        }
        
        // If it's a directory, try to serve index.html from it
        if (stats.isDirectory()) {
            const indexPath = path.join(fullPath, 'index.html');
            fs.readFile(indexPath, (err, content) => {
                if (err) {
                    res.writeHead(403, { 'Content-Type': 'text/html' });
                    res.end('<h1>403 Forbidden - Directory listing not allowed</h1>');
                } else {
                    res.writeHead(200, { 'Content-Type': 'text/html' });
                    res.end(content);
                }
            });
            return;
        }
        
        // It's a file, serve it
        const contentType = mimeTypes[extname] || 'application/octet-stream';
        fs.readFile(fullPath, (error, content) => {
            if (error) {
                console.error('Error:', error.code);
                if (error.code === 'ENOENT') {
                    res.writeHead(404, { 'Content-Type': 'text/html' });
                    res.end('<h1>404 Not Found</h1>');
                } else {
                    res.writeHead(500);
                    res.end('Server Error: ' + error.code);
                }
            } else {
                console.log('Serving:', filePath);
                res.writeHead(200, { 'Content-Type': contentType });
                res.end(content);
            }
        });
    });
});

const PORT = 3333;
server.listen(PORT, '127.0.0.1', () => {
    console.log('========================================');
    console.log('Server running at http://127.0.0.1:' + PORT + '/');
    console.log('Directory:', __dirname);
    console.log('========================================');
});

// Keep the process running
process.stdin.resume();
