/**
 * UI模块
 * 封装所有UI交互功能
 */

const UIModule = {
    // Toast提示
    showToast: function(message) {
        const toast = document.getElementById('toast');
        if (!toast) return;
        
        toast.textContent = message;
        toast.style.opacity = '1';
        
        setTimeout(() => {
            toast.style.opacity = '0';
        }, 2000);
    },

    // 侧边菜单切换
    toggleMenu: function() {
        const sideMenu = document.getElementById('sideMenu');
        const menuOverlay = document.getElementById('menuOverlay');
        
        if (!sideMenu || !menuOverlay) return;
        
        if (sideMenu.classList.contains('translate-x-full')) {
            // 显示菜单
            sideMenu.classList.remove('translate-x-full');
            menuOverlay.classList.remove('hidden');
            document.body.style.overflow = 'hidden';
        } else {
            // 隐藏菜单
            sideMenu.classList.add('translate-x-full');
            menuOverlay.classList.add('hidden');
            document.body.style.overflow = '';
        }
    },

    // 显示消息面板
    showMessagesPanel: function() {
        const panel = document.getElementById('messagesPanel');
        const overlay = document.getElementById('messagesOverlay');
        
        if (!panel || !overlay) return;
        
        panel.classList.remove('translate-x-full');
        overlay.classList.remove('hidden');
        document.body.style.overflow = 'hidden';
        
        // 加载保存的消息状态
        if (typeof loadMessageState === 'function') {
            loadMessageState();
        }
    },

    // 隐藏消息面板
    hideMessagesPanel: function() {
        const panel = document.getElementById('messagesPanel');
        const overlay = document.getElementById('messagesOverlay');
        
        if (!panel || !overlay) return;
        
        panel.classList.add('translate-x-full');
        overlay.classList.add('hidden');
        document.body.style.overflow = 'auto';
    },

    // 显示设置模态框
    showSettingsModal: function() {
        const modal = document.getElementById('settingsModal');
        if (!modal) return;
        
        modal.classList.remove('hidden');
        modal.classList.add('flex');
        document.body.style.overflow = 'hidden';
        
        // 从本地存储加载设置
        if (typeof loadSettings === 'function') {
            loadSettings();
        }
    },

    // 隐藏设置模态框
    hideSettingsModal: function() {
        const modal = document.getElementById('settingsModal');
        if (!modal) return;
        
        modal.classList.add('hidden');
        modal.classList.remove('flex');
        document.body.style.overflow = 'auto';
    },

    // 显示关于我们模态框
    showAboutModal: function() {
        const modal = document.getElementById('aboutModal');
        if (!modal) return;
        
        modal.classList.remove('hidden');
        modal.classList.add('flex');
        document.body.style.overflow = 'hidden';
    },

    // 隐藏关于我们模态框
    hideAboutModal: function() {
        const modal = document.getElementById('aboutModal');
        if (!modal) return;
        
        modal.classList.add('hidden');
        modal.classList.remove('flex');
        document.body.style.overflow = 'auto';
    },

    // 打开搜索模态框
    openSearchModal: function() {
        const modal = document.getElementById('searchModal');
        const input = document.getElementById('searchInput');
        
        if (!modal) return;
        
        modal.classList.remove('hidden');
        document.body.style.overflow = 'hidden';
        
        if (input) {
            setTimeout(() => {
                input.focus();
            }, 100);
        }
    },

    // 关闭搜索模态框
    closeSearchModal: function() {
        const modal = document.getElementById('searchModal');
        if (!modal) return;
        
        modal.classList.add('hidden');
        document.body.style.overflow = '';
    },

    // 标记消息为已读
    markMessageAsRead: function(messageId) {
        const messages = document.querySelectorAll('#messagesPanel .glass-card');
        const message = messages[messageId - 1];
        
        if (message) {
            message.style.opacity = '0.6';
            
            const unreadDot = message.querySelector('.bg-primary.rounded-full');
            if (unreadDot) {
                unreadDot.remove();
            }
            
            if (typeof updateUnreadCount === 'function') {
                updateUnreadCount();
            }
            if (typeof saveMessageState === 'function') {
                saveMessageState();
            }
        }
    },

    // 清空所有消息
    clearAllMessages: function() {
        const messages = document.querySelectorAll('#messagesPanel .glass-card');
        
        if (confirm('确定要清空所有消息吗？此操作不可恢复。')) {
            messages.forEach(message => {
                message.style.opacity = '0.6';
                
                const unreadDot = message.querySelector('.bg-primary.rounded-full');
                if (unreadDot) {
                    unreadDot.remove();
                }
            });
            
            if (typeof updateUnreadCount === 'function') {
                updateUnreadCount();
            }
            if (typeof saveMessageState === 'function') {
                saveMessageState();
            }
        }
    },

    // 更新未读消息数量
    updateUnreadCount: function() {
        const unreadDots = document.querySelectorAll('#messagesPanel .bg-primary.rounded-full');
        const unreadCount = unreadDots.length;
        const badge = document.querySelector('.fa-bell')?.nextElementSibling;
        
        if (badge) {
            if (unreadCount > 0) {
                badge.textContent = unreadCount;
                badge.classList.remove('hidden');
            } else {
                badge.classList.add('hidden');
            }
        }
    },

    // 保存消息状态
    saveMessageState: function() {
        const messages = document.querySelectorAll('#messagesPanel .glass-card');
        const messageStates = [];
        
        messages.forEach((message, index) => {
            const isRead = message.style.opacity === '0.6';
            const hasUnreadDot = message.querySelector('.bg-primary.rounded-full') !== null;
            
            messageStates.push({
                id: index + 1,
                isRead: isRead,
                hasUnreadDot: hasUnreadDot
            });
        });
        
        localStorage.setItem('dingzhouTravel_messages', JSON.stringify(messageStates));
    },

    // 加载消息状态
    loadMessageState: function() {
        const savedStates = localStorage.getItem('dingzhouTravel_messages');
        
        if (savedStates) {
            const messageStates = JSON.parse(savedStates);
            const messages = document.querySelectorAll('#messagesPanel .glass-card');
            
            messageStates.forEach(state => {
                const message = messages[state.id - 1];
                if (message) {
                    if (state.isRead) {
                        message.style.opacity = '0.6';
                    }
                    
                    if (!state.hasUnreadDot) {
                        const unreadDot = message.querySelector('.bg-primary.rounded-full');
                        if (unreadDot) {
                            unreadDot.remove();
                        }
                    }
                }
            });
        }
        
        this.updateUnreadCount();
    }
};

// 导出模块
if (typeof module !== 'undefined' && module.exports) {
    module.exports = UIModule;
} else {
    window.UIModule = UIModule;
    
    // 为了兼容性，保留全局函数
    window.showToast = UIModule.showToast.bind(UIModule);
    window.toggleMenu = UIModule.toggleMenu.bind(UIModule);
    window.showMessagesPanel = UIModule.showMessagesPanel.bind(UIModule);
    window.hideMessagesPanel = UIModule.hideMessagesPanel.bind(UIModule);
    window.showSettingsModal = UIModule.showSettingsModal.bind(UIModule);
    window.hideSettingsModal = UIModule.hideSettingsModal.bind(UIModule);
    window.showAboutModal = UIModule.showAboutModal.bind(UIModule);
    window.hideAboutModal = UIModule.hideAboutModal.bind(UIModule);
    window.openSearchModal = UIModule.openSearchModal.bind(UIModule);
    window.closeSearchModal = UIModule.closeSearchModal.bind(UIModule);
    window.markMessageAsRead = UIModule.markMessageAsRead.bind(UIModule);
    window.clearAllMessages = UIModule.clearAllMessages.bind(UIModule);
    window.updateUnreadCount = UIModule.updateUnreadCount.bind(UIModule);
    window.saveMessageState = UIModule.saveMessageState.bind(UIModule);
    window.loadMessageState = UIModule.loadMessageState.bind(UIModule);
}
