# 项目规则

## 环境配置

### Python 服务器
- 在此环境中，启动 Python HTTP 服务器需要使用 `py` 命令，而不是 `python`
- 正确命令：`py -m http.server 8080`
- 错误命令：`python -m http.server 8080` (会导致服务器无法启动)

## 文件修改记录

### 导航栏统一修改 (已完成)
- index.html: 底部导航栏改为讨论页面样式
- profile.html: 底部导航栏改为讨论页面样式，删除侧边菜单
- 所有页面滚动条已隐藏
