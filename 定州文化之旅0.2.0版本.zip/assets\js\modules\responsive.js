/**
 * 响应式设计模块
 * 包含移动端特定的交互和优化功能
 */

// 响应式设计模块
const ResponsiveModule = {
    // 初始化响应式设计功能
    init: function() {
        console.log('Responsive module initialized');
        this.initMobileDetection();
        this.initTouchGestures();
        this.initResponsiveMenu();
        this.initViewportAdjustments();
        this.initMobileOptimizations();
    },
    
    // 初始化移动设备检测
    initMobileDetection: function() {
        // 检测移动设备
        this.isMobile = this.detectMobile();
        this.isTablet = this.detectTablet();
        this.isDesktop = !this.isMobile && !this.isTablet;
        
        // 添加设备类型类到根元素
        if (this.isMobile) {
            document.documentElement.classList.add('mobile-device');
        } else if (this.isTablet) {
            document.documentElement.classList.add('tablet-device');
        } else {
            document.documentElement.classList.add('desktop-device');
        }
        
        // 检测触摸设备
        this.isTouchDevice = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
        if (this.isTouchDevice) {
            document.documentElement.classList.add('touch-device');
        }
    },
    
    // 检测移动设备
    detectMobile: function() {
        return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    },
    
    // 检测平板设备
    detectTablet: function() {
        const width = window.innerWidth;
        return width >= 768 && width < 1024;
    },
    
    // 初始化触摸手势
    initTouchGestures: function() {
        if (this.isTouchDevice) {
            this.initSwipeGestures();
            this.initTouchFeedback();
            this.initDoubleTapZoom();
        }
    },
    
    // 初始化滑动手势
    initSwipeGestures: function() {
        let startX, startY, endX, endY;
        
        document.addEventListener('touchstart', function(e) {
            startX = e.touches[0].clientX;
            startY = e.touches[0].clientY;
        }, false);
        
        document.addEventListener('touchend', function(e) {
            endX = e.changedTouches[0].clientX;
            endY = e.changedTouches[0].clientY;
            
            // 计算滑动距离
            const diffX = startX - endX;
            const diffY = startY - endY;
            
            // 检测水平滑动
            if (Math.abs(diffX) > Math.abs(diffY) && Math.abs(diffX) > 50) {
                if (diffX > 0) {
                    // 左滑
                    ResponsiveModule.handleSwipeLeft();
                } else {
                    // 右滑
                    ResponsiveModule.handleSwipeRight();
                }
            }
            
            // 检测垂直滑动
            if (Math.abs(diffY) > Math.abs(diffX) && Math.abs(diffY) > 50) {
                if (diffY > 0) {
                    // 上滑
                    ResponsiveModule.handleSwipeUp();
                } else {
                    // 下滑
                    ResponsiveModule.handleSwipeDown();
                }
            }
        }, false);
    },
    
    // 处理左滑手势
    handleSwipeLeft: function() {
        console.log('Swipe left detected');
        // 这里可以添加左滑手势的处理逻辑
        // 例如：打开侧边菜单
        const sideMenu = document.getElementById('sideMenu');
        if (sideMenu && sideMenu.classList.contains('translate-x-full')) {
            UIModule.toggleMenu();
        }
    },
    
    // 处理右滑手势
    handleSwipeRight: function() {
        console.log('Swipe right detected');
        // 这里可以添加右滑手势的处理逻辑
        // 例如：关闭侧边菜单
        const sideMenu = document.getElementById('sideMenu');
        if (sideMenu && !sideMenu.classList.contains('translate-x-full')) {
            UIModule.toggleMenu();
        }
    },
    
    // 处理上滑手势
    handleSwipeUp: function() {
        console.log('Swipe up detected');
        // 这里可以添加上滑手势的处理逻辑
    },
    
    // 处理下滑手势
    handleSwipeDown: function() {
        console.log('Swipe down detected');
        // 这里可以添加下滑手势的处理逻辑
    },
    
    // 初始化触摸反馈
    initTouchFeedback: function() {
        // 为可点击元素添加触摸反馈
        const clickableElements = document.querySelectorAll('button, a, [role="button"], .cursor-pointer');
        clickableElements.forEach(element => {
            element.addEventListener('touchstart', function() {
                this.style.transform = 'scale(0.95)';
                this.style.transition = 'transform 0.1s ease';
            });
            
            element.addEventListener('touchend', function() {
                this.style.transform = 'scale(1)';
            });
            
            element.addEventListener('touchcancel', function() {
                this.style.transform = 'scale(1)';
            });
        });
    },
    
    // 初始化双击缩放
    initDoubleTapZoom: function() {
        // 这里可以添加双击缩放的处理逻辑
    },
    
    // 初始化响应式菜单
    initResponsiveMenu: function() {
        // 确保菜单在移动设备上正常工作
        if (this.isMobile) {
            // 为菜单按钮添加额外的触摸事件处理
            const menuButton = document.querySelector('[onclick="UIModule.toggleMenu()"]');
            if (menuButton) {
                menuButton.addEventListener('touchstart', function(e) {
                    e.preventDefault();
                    UIModule.toggleMenu();
                });
            }
        }
    },
    
    // 初始化视口调整
    initViewportAdjustments: function() {
        // 处理移动设备的视口调整
        this.updateViewport();
        
        // 监听窗口大小变化
        window.addEventListener('resize', () => {
            this.updateViewport();
        });
    },
    
    // 更新视口
    updateViewport: function() {
        const viewport = document.querySelector('meta[name="viewport"]');
        if (viewport) {
            // 确保视口设置正确
            viewport.setAttribute('content', 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no');
        }
    },
    
    // 初始化移动设备优化
    initMobileOptimizations: function() {
        if (this.isMobile) {
            this.optimizeMobilePerformance();
            this.initMobileSpecificFeatures();
        }
    },
    
    // 优化移动设备性能
    optimizeMobilePerformance: function() {
        // 减少动画复杂度
        document.documentElement.classList.add('mobile-performance');
        
        // 优化图片加载
        this.optimizeImageLoading();
        
        // 优化滚动性能
        this.optimizeScrolling();
    },
    
    // 优化图片加载
    optimizeImageLoading: function() {
        // 为移动设备使用低分辨率图片
        const images = document.querySelectorAll('img');
        images.forEach(img => {
            // 这里可以添加图片优化逻辑
            // 例如：使用srcset或picture元素来提供不同分辨率的图片
        });
    },
    
    // 优化滚动性能
    optimizeScrolling: function() {
        // 使用passive事件监听器
        window.addEventListener('scroll', this.handleScroll, { passive: true });
    },
    
    // 处理滚动事件
    handleScroll: function() {
        // 这里可以添加滚动事件的处理逻辑
        // 例如：滚动时隐藏导航栏
    },
    
    // 初始化移动设备特定功能
    initMobileSpecificFeatures: function() {
        // 添加移动设备特定的功能
        this.initPullToRefresh();
        this.initInfiniteScroll();
    },
    
    // 初始化下拉刷新
    initPullToRefresh: function() {
        let startY;
        let pullDistance = 0;
        const threshold = 80;
        let isPulling = false;
        
        document.addEventListener('touchstart', function(e) {
            // 只有在页面顶部才能下拉刷新
            if (window.scrollY === 0) {
                startY = e.touches[0].clientY;
                isPulling = true;
            }
        }, false);
        
        document.addEventListener('touchmove', function(e) {
            if (isPulling && window.scrollY === 0) {
                const currentY = e.touches[0].clientY;
                pullDistance = currentY - startY;
                
                if (pullDistance > 0) {
                    e.preventDefault();
                    // 这里可以添加下拉刷新的视觉反馈
                }
            }
        }, false);
        
        document.addEventListener('touchend', function() {
            if (isPulling && pullDistance > threshold) {
                // 执行刷新操作
                ResponsiveModule.performRefresh();
            }
            
            isPulling = false;
            pullDistance = 0;
        }, false);
    },
    
    // 执行刷新操作
    performRefresh: function() {
        console.log('Performing refresh');
        // 这里可以添加刷新操作的逻辑
        // 例如：重新加载页面或更新内容
        window.location.reload();
    },
    
    // 初始化无限滚动
    initInfiniteScroll: function() {
        // 这里可以添加无限滚动的处理逻辑
    },
    
    // 获取设备信息
    getDeviceInfo: function() {
        return {
            isMobile: this.isMobile,
            isTablet: this.isTablet,
            isDesktop: this.isDesktop,
            isTouchDevice: this.isTouchDevice,
            screenWidth: window.innerWidth,
            screenHeight: window.innerHeight
        };
    }
};

// 导出响应式设计模块
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ResponsiveModule;
} else {
    window.ResponsiveModule = ResponsiveModule;
}
