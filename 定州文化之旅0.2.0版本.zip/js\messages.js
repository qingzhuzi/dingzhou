// 消息通知共享组件
// 所有页面统一使用此组件

const MESSAGES_DATA = [
    {
        id: 1,
        type: 'profile',
        icon: 'fa-user',
        iconBg: 'bg-yellow-500/20',
        iconColor: 'text-yellow-400',
        title: '个人资料',
        content: '完成个人资料，获得专属旅游路线推荐！完善您的头像、昵称等信息，解锁更多个性化功能。',
        time: '刚刚',
        action: 'profile'
    },
    {
        id: 2,
        type: 'welcome',
        icon: 'fa-gift',
        iconBg: 'bg-purple-500/20',
        iconColor: 'text-purple-400',
        title: '欢迎加入',
        content: '欢迎使用定州文化之旅！快来探索定州的魅力吧。在这里您可以发现定州的历史文化、特色美食、民俗风情。',
        time: '刚刚',
        action: 'modal'
    }
];

// 获取消息已读状态
function getMessageStates() {
    const saved = localStorage.getItem('dingzhouTravel_messages_v3');
    if (saved) {
        return JSON.parse(saved);
    }
    const defaultStates = {};
    MESSAGES_DATA.forEach(msg => {
        defaultStates[msg.id] = false;
    });
    return defaultStates;
}

// 保存消息已读状态
function saveMessageStates(states) {
    localStorage.setItem('dingzhouTravel_messages_v3', JSON.stringify(states));
}

// 获取未读消息数量
function getUnreadCount() {
    const states = getMessageStates();
    return MESSAGES_DATA.filter(msg => !states[msg.id]).length;
}

// 更新未读消息角标
function updateUnreadCount() {
    const count = getUnreadCount();
    const badges = document.querySelectorAll('.notification-badge');
    badges.forEach(badge => {
        if (count > 0) {
            badge.textContent = count;
            badge.classList.remove('hidden');
        } else {
            badge.classList.add('hidden');
        }
    });
}

// 渲染消息列表
function renderMessages() {
    const container = document.getElementById('messagesList');
    if (!container) return;
    
    const states = getMessageStates();
    
    container.innerHTML = MESSAGES_DATA.map(msg => {
        const isRead = states[msg.id];
        return `
            <div class="glass-card p-4 rounded-xl hover:bg-white/20 transition-all duration-300 cursor-pointer ${isRead ? 'opacity-60' : ''}" 
                 onclick="handleMessageClick(${msg.id})">
                <div class="flex items-start space-x-3">
                    <div class="w-10 h-10 ${msg.iconBg} rounded-full flex items-center justify-center flex-shrink-0">
                        <i class="fa ${msg.icon} ${msg.iconColor}"></i>
                    </div>
                    <div class="flex-1">
                        <div class="flex justify-between items-start">
                            <h4 class="font-semibold text-white">${msg.title}</h4>
                            <span class="text-xs text-white/60">${msg.time}</span>
                        </div>
                        <p class="text-sm text-white/70 mt-1">${msg.content.substring(0, 30)}...</p>
                        ${!isRead ? '<div class="w-2 h-2 bg-primary rounded-full mt-2 animate-pulse"></div>' : ''}
                    </div>
                </div>
            </div>
        `;
    }).join('');
}

// 处理消息点击
function handleMessageClick(messageId) {
    const message = MESSAGES_DATA.find(m => m.id === messageId);
    if (!message) return;
    
    // 标记为已读
    const states = getMessageStates();
    states[messageId] = true;
    saveMessageStates(states);
    
    // 更新UI
    renderMessages();
    updateUnreadCount();
    
    // 根据消息类型执行不同操作
    switch (message.action) {
        case 'modal':
            showMessageDetail(message);
            break;
        case 'profile':
            hideMessagesPanel();
            window.location.href = 'profile.html';
            break;
    }
}

// 显示消息详情弹窗
function showMessageDetail(message) {
    const modal = document.getElementById('messageDetailModal');
    if (!modal) return;
    
    modal.innerHTML = `
        <div class="glass-card rounded-3xl p-0 max-w-sm w-full overflow-hidden" style="animation: modalSlideIn 0.3s ease;">
            <!-- 顶部图片区域 -->
            <div class="relative h-40 bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                <div class="absolute inset-0 bg-black/20"></div>
                <div class="relative z-10 text-center">
                    <div class="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-2 backdrop-blur-sm">
                        <i class="fa fa-gift text-4xl text-white"></i>
                    </div>
                    <h4 class="text-xl font-bold text-white">${message.title}</h4>
                </div>
            </div>
            
            <!-- 内容区域 -->
            <div class="p-6">
                <p class="text-white/90 text-base leading-relaxed mb-4">${message.content}</p>
                
                <!-- 特色标签 -->
                <div class="flex flex-wrap gap-2 mb-4">
                    <span class="px-3 py-1 bg-primary/20 text-primary rounded-full text-xs">历史文化</span>
                    <span class="px-3 py-1 bg-green-500/20 text-green-400 rounded-full text-xs">特色美食</span>
                    <span class="px-3 py-1 bg-yellow-500/20 text-yellow-400 rounded-full text-xs">民俗风情</span>
                </div>
                
                <!-- 时间信息 -->
                <div class="flex items-center text-white/50 text-sm mb-4">
                    <i class="fa fa-clock-o mr-2"></i>
                    <span>${message.time}</span>
                </div>
                
                <!-- 关闭按钮 -->
                <button onclick="hideMessageDetail()" 
                    class="w-full py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-xl font-semibold hover:opacity-90 transition-opacity">
                    我知道了
                </button>
            </div>
        </div>
    `;
    
    modal.classList.remove('hidden');
    modal.classList.add('flex');
}

// 隐藏消息详情弹窗
function hideMessageDetail() {
    const modal = document.getElementById('messageDetailModal');
    if (modal) {
        modal.classList.add('hidden');
        modal.classList.remove('flex');
    }
}

// 显示消息面板
function showMessagesPanel() {
    const panel = document.getElementById('messagesPanel');
    const overlay = document.getElementById('messagesOverlay');
    
    if (panel && overlay) {
        panel.classList.remove('translate-x-full');
        overlay.classList.remove('hidden');
        document.body.style.overflow = 'hidden';
        
        renderMessages();
        updateUnreadCount();
    }
}

// 隐藏消息面板
function hideMessagesPanel() {
    const panel = document.getElementById('messagesPanel');
    const overlay = document.getElementById('messagesOverlay');
    
    if (panel && overlay) {
        panel.classList.add('translate-x-full');
        overlay.classList.add('hidden');
        document.body.style.overflow = 'auto';
    }
}

// 清空所有消息
function clearAllMessages() {
    if (confirm('确定要清空所有消息吗？此操作不可恢复。')) {
        const states = getMessageStates();
        MESSAGES_DATA.forEach(msg => {
            states[msg.id] = true;
        });
        saveMessageStates(states);
        
        renderMessages();
        updateUnreadCount();
        
        if (typeof showToast === 'function') {
            showToast('所有消息已清空');
        }
    }
}

// 监听localStorage变化，实现跨页面同步
window.addEventListener('storage', function(e) {
    if (e.key === 'dingzhouTravel_messages_v3') {
        renderMessages();
        updateUnreadCount();
    }
});

// 添加弹窗动画样式
const style = document.createElement('style');
style.textContent = `
    @keyframes modalSlideIn {
        from {
            opacity: 0;
            transform: scale(0.9) translateY(20px);
        }
        to {
            opacity: 1;
            transform: scale(1) translateY(0);
        }
    }
`;
document.head.appendChild(style);

// 页面加载时初始化
document.addEventListener('DOMContentLoaded', function() {
    updateUnreadCount();
});
