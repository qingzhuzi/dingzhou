/**
 * 数据模块
 * 集中管理所有应用数据
 */

// 景点数据
const AttractionData = {
    kaiyuanPagoda: {
        name: '开元寺塔',
        image: 'https://p11-doubao-search-sign.byteimg.com/tos-cn-i-be4g95zd3a/1402933981981573125~tplv-be4g95zd3a-image.jpeg?lk3s=feb11e32&x-expires=1786159468&x-signature=gZpUGCelJYEJecMLAwtQqHOF4yY%3D',
        location: '定州市区',
        hours: '08:00 - 17:30',
        description: '始建于北宋，是中国现存最高的砖木结构古塔之一，素有"中华第一塔"之称。塔高83.7米，共11层，塔身呈八角形，造型优美，结构精巧。',
        history: '开元寺塔始建于北宋咸平四年（1001年），历时55年建成。最初是为了供奉西域高僧所献的佛骨舍利而建，后来成为定州的标志性建筑。',
        features: [
            '中国现存最高的砖木结构古塔之一',
            '塔内有丰富的佛教文物和壁画',
            '登塔可俯瞰定州全景',
            '塔身有精美的雕刻和装饰'
        ]
    },
    confucianTemple: {
        name: '定州文庙',
        image: 'https://p3-doubao-search-sign.byteimg.com/labis/98566255725b9c412e6a830b9296c6ab~tplv-be4g95zd3a-image.jpeg?lk3s=feb11e32&x-expires=1786005060&x-signature=FFkj54HXuHJVLrd7f0kZr2zr0s0%3D',
        location: '定州市区',
        hours: '09:00 - 17:00',
        description: '河北省重点文物保护单位，始建于唐代，是中国北方保存最为完整的文庙之一。文庙占地面积约1.2万平方米，建筑布局严谨，规模宏大。',
        history: '定州文庙始建于唐大中二年（848年），历经宋、元、明、清各代重修扩建，形成了现在的规模。是定州重要的文化遗产和旅游景点。',
        features: [
            '中国北方保存最为完整的文庙之一',
            '有保存完好的古代建筑和文物',
            '每年举办祭孔大典等文化活动',
            '环境幽静，文化氛围浓厚'
        ]
    },
    ancientStreet: {
        name: '定州古街',
        image: 'https://p26-doubao-search-sign.byteimg.com/labis/b200274f02448ebe74032a8c0451d232~tplv-be4g95zd3a-image.jpeg?lk3s=feb11e32&x-expires=1786005060&x-signature=nTfZeInPv%2FNPd2g%2FeVJ7LYq%2B8Sg%3D',
        location: '定州古城内',
        hours: '全天开放',
        description: '保存了大量明清时期的建筑，街道两旁店铺林立，展现了定州传统的商业文化和生活方式。古街全长约1.5公里，是定州古城的核心区域。',
        history: '定州古街形成于明清时期，是定州历史上重要的商业中心。街道两旁的建筑大多保持着明清时期的风格，是研究中国古代城市商业发展的重要实物资料。',
        features: [
            '保存完好的明清时期建筑群',
            '传统商业文化的活化石',
            '有众多特色小吃和手工艺品',
            '适合漫步游览，感受历史氛围'
        ]
    },
    ancientCityWall: {
        name: '定州古城墙',
        image: 'https://p26-doubao-search-sign.byteimg.com/labis/dc957070a36414200d673dbbfdeb892e~tplv-be4g95zd3a-image.jpeg?lk3s=feb11e32&x-expires=1786005060&x-signature=VDtgOvARn5AEZpLbA8f53WENj5A%3D',
        location: '定州古城周围',
        hours: '08:30 - 17:00',
        description: '始建于明代，是中国北方保存较好的古城墙之一，城墙高约12米，宽约6米，周长约4.5公里。城墙设有城门、敌楼、马面等防御设施。',
        history: '定州古城墙始建于明洪武年间（1368-1398年），是为了防御北方游牧民族的入侵而建。历经多次修缮，至今仍保持着明代的基本面貌。',
        features: [
            '中国北方保存较好的古城墙之一',
            '完整的防御体系和设施',
            '城墙坚固，气势恢宏',
            '适合骑行或步行游览'
        ]
    }
};

// 美食数据
const FoodData = {
    dingzhouChicken: {
        name: '定州烧鸡',
        image: 'https://p26-doubao-search-sign.byteimg.com/labis/28735074eaa6fa9e786fca41e5ab9690~tplv-be4g95zd3a-image.jpeg?lk3s=feb11e32&x-expires=1786005061&x-signature=MVcd8I1SJyKnP9TCOwfKHoA615c%3D',
        location: '定州市区各大餐馆',
        hours: '10:00 - 22:00',
        description: '定州烧鸡是定州传统特色小吃，选用本地散养土鸡，经传统工艺制作而成，皮脆肉嫩，香味浓郁。',
        history: '定州烧鸡历史悠久，据传起源于清代，至今已有200多年的历史。',
        reasons: [
            '选用本地散养土鸡，肉质鲜美',
            '传统制作工艺，保持原汁原味',
            '皮脆肉嫩，香味浓郁'
        ]
    },
    dongpoPork: {
        name: '北派东坡肘子',
        image: 'https://p11-doubao-search-sign.byteimg.com/pgc-image/5696895b24fe4a3d8cfcce069876a03e~tplv-be4g95zd3a-image.jpeg?lk3s=feb11e32&x-expires=1786005061&x-signature=twID4UrMMROmA8pb09cyvRSOiuc%3D',
        location: '定州市区各大餐馆',
        hours: '11:00 - 21:00',
        description: '定州传统名菜，因苏东坡任定州知州时所创而得名。肘子香而不腻，味道醇厚，是定州传统宴席上的必备菜品。',
        history: '北派东坡肘子始创于北宋年间，苏东坡任定州知州时，将川菜东坡肉的做法与北方饮食习惯相结合，创造出了这道独具特色的菜品。',
        reasons: [
            '历史悠久，文化底蕴深厚',
            '香而不腻，适合北方口味',
            '制作工艺独特，风味纯正'
        ]
    },
    dingzhouStew: {
        name: '定州焖子',
        image: 'https://p11-doubao-search-sign.byteimg.com/labis/e9da3e1cd8cf06d8f9fcd1feb6d578a0~tplv-be4g95zd3a-image.jpeg?lk3s=feb11e32&x-expires=1786158593&x-signature=E%2Byi9mieJDn6%2Bto1DySitrr8UvI%3D',
        location: '定州市区各大餐馆、小吃店',
        hours: '08:00 - 20:00',
        description: '定州特色小吃，由红薯淀粉、猪肉、调料等制成，口感Q弹，风味独特，是定州人民喜爱的传统美食。',
        history: '定州焖子起源于清代，最初是贫苦百姓为了节省食材而发明的一种食品，后来逐渐发展成为定州的特色小吃。',
        reasons: [
            '口感Q弹，风味独特',
            '制作工艺传统，保持原汁原味',
            '价格实惠，深受当地人民喜爱'
        ]
    }
};

// 年俗数据
const CustomData = {
    lanternFestival: {
        name: '正月十五闹元宵',
        image: 'https://p26-doubao-search-sign.byteimg.com/tos-cn-i-xv4ileqgde/0b5a21a13230492e87b663f5dc3b0d4e~tplv-be4g95zd3a-image.jpeg?lk3s=feb11e32&x-expires=1786159149&x-signature=yc41%2F7VCPrWR9a%2FQEUuoqpQFSi0%3D',
        date: '农历正月十五',
        description: '定州传统民俗活动，包括舞龙灯、踩高跷、跑旱船等，热闹非凡，展现了定州人民的喜庆生活。',
        history: '正月十五闹元宵是定州传统的民俗活动，已有数百年的历史。每年元宵节期间，定州各地都会举办丰富多彩的庆祝活动。',
        activities: [
            '舞龙灯表演',
            '踩高跷比赛',
            '跑旱船游行',
            '猜灯谜活动'
        ]
    },
    dingzhouFlowerFestival: {
        name: '定州花会',
        image: 'https://p3-doubao-search-sign.byteimg.com/labis/1639a7c82dd1d22afa80954ba7267eac~tplv-be4g95zd3a-image.jpeg?lk3s=feb11e32&x-expires=1786159149&x-signature=LKzsfovUjln823qpbaihDX8qOXs%3D',
        date: '农历正月十五至二十',
        description: '定州传统民间艺术表演，集音乐、舞蹈、杂技于一体，具有浓郁的地方特色和文化底蕴。',
        history: '定州花会起源于明清时期，是定州传统的民间艺术表演形式。花会表演内容丰富，形式多样，深受当地人民喜爱。',
        activities: [
            '传统音乐演奏',
            '民间舞蹈表演',
            '杂技技艺展示',
            '地方戏曲演出'
        ]
    }
};

// 搜索数据
const SearchData = [
    { id: 1, name: '开元寺塔', type: 'attraction', description: '定州标志性建筑，千年古塔', tags: ['古迹', '塔', '历史'] },
    { id: 2, name: '定州贡院', type: 'attraction', description: '古代科举考试场所', tags: ['古迹', '历史', '文化'] },
    { id: 3, name: '定州文庙', type: 'attraction', description: '祭祀孔子的场所', tags: ['古迹', '文庙', '儒家'] },
    { id: 4, name: '定州清真寺', type: 'attraction', description: '历史悠久的伊斯兰建筑', tags: ['宗教', '建筑', '历史'] },
    { id: 5, name: '定州焖子', type: 'food', description: '定州特色传统美食', tags: ['美食', '特产', '小吃'] },
    { id: 6, name: '中山松醪酒', type: 'food', description: '历史名酒，口感醇厚', tags: ['美食', '酒', '特产'] },
    { id: 7, name: '定州手掰肠', type: 'food', description: '传统风味小吃', tags: ['美食', '小吃', '特产'] },
    { id: 8, name: '正月十五闹元宵', type: 'custom', description: '传统民俗活动', tags: ['民俗', '节日', '文化'] },
    { id: 9, name: '中山文化', type: 'culture', description: '定州历史文化底蕴', tags: ['文化', '历史', '中山国'] }
];

// AI路线规划数据
const RouteData = {
    attractions: [
        { name: '开元寺塔', time: '2小时', type: 'attraction' },
        { name: '定州文庙', time: '1.5小时', type: 'attraction' },
        { name: '定州古街', time: '2小时', type: 'attraction' },
        { name: '定州古城墙', time: '1小时', type: 'attraction' }
    ],
    foods: [
        { name: '定州烧鸡', time: '1小时', type: 'food' },
        { name: '北派东坡肘子', time: '1小时', type: 'food' },
        { name: '定州焖子', time: '0.5小时', type: 'food' }
    ],
    activities: [
        { name: '正月十五闹元宵', time: '3小时', type: 'activity' },
        { name: '定州花会', time: '2小时', type: 'activity' }
    ]
};

// 导出数据模块
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { AttractionData, FoodData, CustomData, SearchData, RouteData };
} else {
    window.AttractionData = AttractionData;
    window.FoodData = FoodData;
    window.CustomData = CustomData;
    window.SearchData = SearchData;
    window.RouteData = RouteData;
}
