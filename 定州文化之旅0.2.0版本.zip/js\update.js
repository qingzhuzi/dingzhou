// 更新公告共享组件

const UPDATE_INFO = {
    version: 'v0.2.0',
    date: '2026年2月13日',
    title: '定州文化之旅',
    updates: [
        {
            icon: 'fa-paint-brush',
            title: '全新UI设计',
            desc: '采用现代化玻璃拟态设计风格，视觉体验全面升级'
        },
        {
            icon: 'fa-magic',
            title: '全新UX体验',
            desc: '优化交互流程，操作更流畅自然，用户体验大幅提升'
        },
        {
            icon: 'fa-sun',
            title: '浅色/深色模式',
            desc: '支持浅色与深色主题切换，保护眼睛，随心所欲'
        },
        {
            icon: 'fa-search',
            title: '智能搜索',
            desc: '新增全局搜索功能，快速查找景点、美食、文化内容'
        },
        {
            icon: 'fa-bars',
            title: '侧边菜单栏',
            desc: '全新侧边导航设计，功能入口一目了然'
        },
        {
            icon: 'fa-location-arrow',
            title: '底部导航栏',
            desc: '便捷底部导航，单手操作更轻松'
        },
        {
            icon: 'fa-bell',
            title: '消息通知中心',
            desc: '实时消息推送，重要信息不遗漏'
        },
        {
            icon: 'fa-comments',
            title: '讨论社区',
            desc: '新增讨论区功能，分享旅行心得，交流互动'
        },
        {
            icon: 'fa-envelope',
            title: '反馈系统',
            desc: '意见反馈通道，您的建议我们认真倾听'
        },
        {
            icon: 'fa-bug',
            title: '问题修复',
            desc: '修复多项已知问题，稳定性与性能全面提升'
        }
    ]
};

// 显示更新公告弹窗
function showUpdateModal() {
    const modal = document.getElementById('updateModal');
    if (!modal) return;
    
    // 禁止背景滚动
    document.body.style.overflow = 'hidden';
    
    modal.innerHTML = `
        <div class="glass-card rounded-2xl p-0 w-11/12 max-w-2xl overflow-hidden" style="animation: modalSlideIn 0.3s ease;" onclick="event.stopPropagation()">
            <!-- 顶部版本区域 -->
            <div class="relative py-6 px-8 flex items-center space-x-6" style="background: linear-gradient(135deg, rgba(59,130,246,0.3), rgba(139,92,246,0.3));">
                <div class="w-16 h-16 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-sm">
                    <i class="fa fa-newspaper-o text-3xl text-white"></i>
                </div>
                <div class="flex-1">
                    <h2 class="text-xl font-bold text-white">${UPDATE_INFO.title}</h2>
                    <div class="flex items-center space-x-3 mt-1">
                        <span class="px-2 py-0.5 bg-white/20 rounded text-white text-sm">${UPDATE_INFO.version}</span>
                        <span class="text-white/60 text-sm">${UPDATE_INFO.date}</span>
                    </div>
                </div>
                <button onclick="hideUpdateModal()" class="text-white/60 hover:text-white transition-colors">
                    <i class="fa fa-times text-xl"></i>
                </button>
            </div>
            
            <!-- 内容区域 -->
            <div class="p-6">
                <h3 class="text-base font-bold text-white mb-4">本次更新</h3>
                
                <!-- 更新列表 - 两列布局 -->
                <div class="grid grid-cols-2 gap-3 mb-5 max-h-64 overflow-y-auto pr-2" style="overscroll-behavior: contain;">
                    ${UPDATE_INFO.updates.map(item => `
                        <div class="flex items-start space-x-2 p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors">
                            <div class="w-7 h-7 bg-primary/20 rounded-lg flex items-center justify-center flex-shrink-0">
                                <i class="fa ${item.icon} text-primary text-xs"></i>
                            </div>
                            <div class="flex-1 min-w-0">
                                <h4 class="text-white font-medium text-sm">${item.title}</h4>
                                <p class="text-white/50 text-xs mt-0.5 line-clamp-2">${item.desc}</p>
                            </div>
                        </div>
                    `).join('')}
                </div>
                
                <!-- 关闭按钮 -->
                <button onclick="hideUpdateModal()" 
                    class="w-full py-2.5 bg-white/10 hover:bg-white/20 text-white rounded-xl font-medium transition-colors border border-white/10">
                    知道了
                </button>
            </div>
        </div>
    `;
    
    modal.classList.remove('hidden');
    modal.classList.add('flex');
}

// 隐藏更新公告弹窗
function hideUpdateModal() {
    const modal = document.getElementById('updateModal');
    if (modal) {
        modal.classList.add('hidden');
        modal.classList.remove('flex');
        // 恢复背景滚动
        document.body.style.overflow = 'auto';
    }
}
