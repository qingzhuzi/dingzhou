/**
 * 深色模式模块
 * 包含深色模式切换、系统主题检测和深色模式优化等功能
 */

// 深色模式模块
const DarkModeModule = {
    // 初始化深色模式功能
    init: function() {
        console.log('Dark mode module initialized');
        this.initDarkModeToggle();
        this.initSystemThemeDetection();
        this.initDarkModeStyles();
        this.initDarkModeTransitions();
    },
    
    // 初始化深色模式切换
    initDarkModeToggle: function() {
        const darkModeToggle = document.getElementById('darkModeToggle');
        
        if (darkModeToggle) {
            // 从本地存储加载深色模式状态
            const isDarkMode = this.isDarkModeEnabled();
            darkModeToggle.checked = isDarkMode;
            
            // 应用初始深色模式状态
            this.applyDarkMode(isDarkMode);
            
            // 添加切换事件监听器
            darkModeToggle.addEventListener('change', (e) => {
                const isDarkMode = e.target.checked;
                this.applyDarkMode(isDarkMode);
                this.saveDarkModeState(isDarkMode);
                this.showThemeChangeNotification(isDarkMode);
            });
        }
    },
    
    // 初始化系统主题检测
    initSystemThemeDetection: function() {
        // 检测系统主题偏好
        const prefersDarkScheme = window.matchMedia('(prefers-color-scheme: dark)');
        
        // 当系统主题变化时更新
        prefersDarkScheme.addEventListener('change', (e) => {
            const isDarkMode = e.matches;
            const darkModeToggle = document.getElementById('darkModeToggle');
            
            if (darkModeToggle) {
                // 只有当用户没有明确设置时才跟随系统
                const savedState = localStorage.getItem('darkMode');
                if (savedState === null) {
                    darkModeToggle.checked = isDarkMode;
                    this.applyDarkMode(isDarkMode);
                    this.showThemeChangeNotification(isDarkMode);
                }
            }
        });
    },
    
    // 初始化深色模式样式
    initDarkModeStyles: function() {
        // 这里可以添加动态生成的深色模式样式
    },
    
    // 初始化深色模式过渡效果
    initDarkModeTransitions: function() {
        // 添加主题切换时的平滑过渡效果
        document.documentElement.style.transition = 'background-color 0.3s ease, color 0.3s ease';
        
        // 为所有元素添加过渡效果
        const elements = document.querySelectorAll('*');
        elements.forEach(element => {
            if (!element.style.transition) {
                element.style.transition = 'background-color 0.3s ease, color 0.3s ease, border-color 0.3s ease';
            }
        });
    },
    
    // 检查是否启用深色模式
    isDarkModeEnabled: function() {
        // 先检查本地存储
        const savedState = localStorage.getItem('darkMode');
        if (savedState !== null) {
            return savedState === 'true';
        }
        
        // 然后检查系统偏好
        const prefersDarkScheme = window.matchMedia('(prefers-color-scheme: dark)');
        return prefersDarkScheme.matches;
    },
    
    // 应用深色模式
    applyDarkMode: function(isDarkMode) {
        if (isDarkMode) {
            document.documentElement.classList.add('dark-mode');
            document.documentElement.setAttribute('data-theme', 'dark');
            // 更新favicon为深色模式版本（如果有）
            this.updateFavicon(isDarkMode);
        } else {
            document.documentElement.classList.remove('dark-mode');
            document.documentElement.setAttribute('data-theme', 'light');
            // 更新favicon为浅色模式版本（如果有）
            this.updateFavicon(isDarkMode);
        }
    },
    
    // 保存深色模式状态到本地存储
    saveDarkModeState: function(isDarkMode) {
        localStorage.setItem('darkMode', isDarkMode.toString());
    },
    
    // 更新favicon
    updateFavicon: function(isDarkMode) {
        // 这里可以添加favicon更新逻辑
        // 例如：
        // const favicon = document.querySelector('link[rel="icon"]');
        // if (favicon) {
        //     favicon.href = isDarkMode ? 'favicon-dark.ico' : 'favicon-light.ico';
        // }
    },
    
    // 显示主题切换通知
    showThemeChangeNotification: function(isDarkMode) {
        const message = isDarkMode ? '已切换到深色模式' : '已切换到浅色模式';
        
        if (typeof UXModule !== 'undefined' && UXModule.showNotification) {
            UXModule.showNotification(message, 'success', 2000);
        } else {
            // 后备通知方法
            this.showToast(message);
        }
    },
    
    // 显示简单的toast通知
    showToast: function(message) {
        const toast = document.createElement('div');
        toast.className = 'fixed bottom-6 left-1/2 transform -translate-x-1/2 bg-black/80 text-white px-4 py-2 rounded-lg z-50 glass-card';
        toast.textContent = message;
        
        document.body.appendChild(toast);
        
        // 显示动画
        toast.style.opacity = '0';
        toast.style.transition = 'opacity 0.3s ease-out';
        setTimeout(() => {
            toast.style.opacity = '1';
        }, 100);
        
        // 自动隐藏
        setTimeout(() => {
            toast.style.opacity = '0';
            setTimeout(() => {
                if (document.body.contains(toast)) {
                    document.body.removeChild(toast);
                }
            }, 300);
        }, 2000);
    },
    
    // 切换深色模式
    toggleDarkMode: function() {
        const darkModeToggle = document.getElementById('darkModeToggle');
        if (darkModeToggle) {
            darkModeToggle.checked = !darkModeToggle.checked;
            const isDarkMode = darkModeToggle.checked;
            this.applyDarkMode(isDarkMode);
            this.saveDarkModeState(isDarkMode);
            this.showThemeChangeNotification(isDarkMode);
        }
    }
};

// 导出深色模式模块
if (typeof module !== 'undefined' && module.exports) {
    module.exports = DarkModeModule;
} else {
    window.DarkModeModule = DarkModeModule;
}
