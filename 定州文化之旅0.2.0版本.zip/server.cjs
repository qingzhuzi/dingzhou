const http = require('http');
const fs = require('fs');
const path = require('path');

const server = http.createServer((req, res) => {
    console.log(`Request: ${req.url}`);
    
    let filePath = req.url;
    if (filePath === '/') filePath = '/index.html';
    
    // 移除查询参数
    filePath = filePath.split('?')[0];
    
    // 构建完整路径
    const fullPath = path.join(__dirname, filePath);
    console.log(`Full path: ${fullPath}`);
    
    const extname = String(path.extname(filePath)).toLowerCase();
    const mimeTypes = {
        '.html': 'text/html',
        '.js': 'text/javascript',
        '.css': 'text/css',
        '.json': 'application/json',
        '.png': 'image/png',
        '.jpg': 'image/jpg',
        '.jpeg': 'image/jpeg',
        '.gif': 'image/gif',
        '.svg': 'image/svg+xml',
        '.ico': 'image/x-icon'
    };
    
    const contentType = mimeTypes[extname] || 'application/octet-stream';
    
    fs.readFile(fullPath, (error, content) => {
        if (error) {
            console.error(`Error reading file: ${error.code}`);
            if (error.code == 'ENOENT') {
                res.writeHead(404, { 'Content-Type': 'text/html' });
                res.end(`<h1>404 Not Found</h1><p>File not found: ${filePath}</p>`);
            } else {
                res.writeHead(500);
                res.end('500 Internal Server Error');
            }
        } else {
            console.log(`Serving file: ${fullPath}`);
            res.writeHead(200, { 'Content-Type': contentType });
            res.end(content, 'utf-8');
        }
    });
});

const PORT = 9999;
server.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}/`);
    console.log(`Serving files from: ${__dirname}`);
    console.log('Press Ctrl+C to stop');
});
