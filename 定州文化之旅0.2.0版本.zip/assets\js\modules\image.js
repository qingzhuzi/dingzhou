/**
 * 图片处理模块
 * 包含图片懒加载、加载状态管理等功能
 */

// 图片处理模块
const ImageModule = {
    // 初始化图片处理功能
    init: function() {
        console.log('Image module initialized');
        this.initLazyLoading();
    },
    
    // 初始化图片懒加载
    initLazyLoading: function() {
        const images = document.querySelectorAll('img[data-src]');
        const loadedImages = new Set();
        
        // 创建IntersectionObserver实例
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    const src = img.dataset.src;
                    
                    // 避免重复加载
                    if (src && !loadedImages.has(src)) {
                        // 添加加载状态
                        img.classList.add('img-loading');
                        
                        img.src = src;
                        loadedImages.add(src);
                        
                        // 图片加载完成后移除data-src属性
                        img.onload = function() {
                            img.removeAttribute('data-src');
                            // 移除加载状态，添加已加载状态
                            img.classList.remove('img-loading');
                            img.classList.add('img-loaded');
                            // 图片加载完成后添加淡入效果
                            img.style.opacity = '0';
                            img.style.transition = 'opacity 0.5s ease-in-out';
                            setTimeout(() => {
                                img.style.opacity = '1';
                            }, 50);
                        };
                        
                        // 图片加载失败时使用占位图
                        img.onerror = function() {
                            // 移除加载状态，添加加载失败状态
                            img.classList.remove('img-loading');
                            img.classList.add('img-error');
                            // 设置错误占位图
                            img.src = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="400" height="300" viewBox="0 0 400 300" fill="none"%3E%3Crect width="400" height="300" fill="%23f0f0f0"/%3E%3Ctext x="200" y="150" font-size="16" text-anchor="middle" fill="%23999"%3E图片加载失败%3C/text%3E%3C/svg%3E';
                            img.removeAttribute('data-src');
                        };
                    }
                    
                    // 停止观察已处理的图片
                    observer.unobserve(img);
                }
            });
        }, {
            // 优化观察器配置
            rootMargin: '200px 0px', // 提前200px开始加载
            threshold: 0.1 // 图片10%进入视口时开始加载
        });
        
        // 观察所有图片
        images.forEach(img => {
            // 为图片添加初始样式
            img.style.opacity = '0';
            imageObserver.observe(img);
        });
        
        // 处理视口变化时的情况
        let resizeTimeout;
        window.addEventListener('resize', function() {
            clearTimeout(resizeTimeout);
            resizeTimeout = setTimeout(() => {
                // 重新观察所有仍有data-src属性的图片
                document.querySelectorAll('img[data-src]').forEach(img => {
                    imageObserver.observe(img);
                });
            }, 250); // 防抖，250ms后执行
        });
    }
};

// 导出图片模块
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ImageModule;
} else {
    window.ImageModule = ImageModule;
}
