/**
 * 定州文旅网站 - 核心JavaScript文件
 * 包含App对象、工具函数、事件管理
 */

// 全局配置
const DZ_CONFIG = {
  storagePrefix: 'dz_',
  apiBaseUrl: '',
  defaultTheme: 'light',
  animationDuration: 300,
  debounceDelay: 300,
  throttleDelay: 100
};

// 全局状态
const DZ_STATE = {
  isDarkMode: false,
  isMenuOpen: false,
  isMessagePanelOpen: false,
  currentUser: null,
  unreadMessages: 0,
  likedItems: new Set(),
  savedItems: new Set()
};

/**
 * 工具函数命名空间
 */
const DZUtils = {
  /**
   * 防抖函数
   * @param {Function} func - 要执行的函数
   * @param {number} wait - 等待时间（毫秒）
   * @returns {Function}
   */
  debounce(func, wait = DZ_CONFIG.debounceDelay) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  },

  /**
   * 节流函数
   * @param {Function} func - 要执行的函数
   * @param {number} limit - 限制时间（毫秒）
   * @returns {Function}
   */
  throttle(func, limit = DZ_CONFIG.throttleDelay) {
    let inThrottle;
    return function executedFunction(...args) {
      if (!inThrottle) {
        func(...args);
        inThrottle = true;
        setTimeout(() => inThrottle = false, limit);
      }
    };
  },

  /**
   * 检查元素是否在视口内
   * @param {Element} element - 要检查的元素
   * @param {number} offset - 偏移量
   * @returns {boolean}
   */
  isInViewport(element, offset = 0) {
    const rect = element.getBoundingClientRect();
    return (
      rect.top >= -offset &&
      rect.left >= 0 &&
      rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) + offset &&
      rect.right <= (window.innerWidth || document.documentElement.clientWidth)
    );
  },

  /**
   * 格式化日期
   * @param {Date|string} date - 日期对象或字符串
   * @param {string} format - 格式字符串
   * @returns {string}
   */
  formatDate(date, format = 'YYYY-MM-DD') {
    const d = new Date(date);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    const hours = String(d.getHours()).padStart(2, '0');
    const minutes = String(d.getMinutes()).padStart(2, '0');
    
    return format
      .replace('YYYY', year)
      .replace('MM', month)
      .replace('DD', day)
      .replace('HH', hours)
      .replace('mm', minutes);
  },

  /**
   * 生成唯一ID
   * @returns {string}
   */
  generateId() {
    return 'dz_' + Math.random().toString(36).substr(2, 9);
  },

  /**
   * 复制到剪贴板
   * @param {string} text - 要复制的文本
   * @returns {Promise<boolean>}
   */
  async copyToClipboard(text) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch (err) {
      // 降级方案
      const textArea = document.createElement('textarea');
      textArea.value = text;
      textArea.style.position = 'fixed';
      textArea.style.left = '-999999px';
      document.body.appendChild(textArea);
      textArea.select();
      try {
        document.execCommand('copy');
        return true;
      } catch (err) {
        return false;
      } finally {
        document.body.removeChild(textArea);
      }
    }
  },

  /**
   * 分享功能
   * @param {Object} data - 分享数据
   */
  async share(data) {
    if (navigator.share) {
      try {
        await navigator.share(data);
        return true;
      } catch (err) {
        return false;
      }
    }
    return false;
  },

  /**
   * 页面跳转
   * @param {string} url - 目标URL
   * @param {boolean} newTab - 是否在新标签页打开
   */
  navigate(url, newTab = false) {
    if (newTab) {
      window.open(url, '_blank');
    } else {
      window.location.href = url;
    }
  },

  /**
   * 安全地获取DOM元素
   * @param {string} selector - CSS选择器
   * @returns {Element|null}
   */
  $(selector) {
    return document.querySelector(selector);
  },

  /**
   * 安全地获取多个DOM元素
   * @param {string} selector - CSS选择器
   * @returns {NodeList}
   */
  $$(selector) {
    return document.querySelectorAll(selector);
  }
};

/**
 * 存储管理器
 */
const DZStorage = {
  /**
   * 获取存储键名
   * @param {string} key - 原始键名
   * @returns {string}
   */
  _getKey(key) {
    return DZ_CONFIG.storagePrefix + key;
  },

  /**
   * 设置存储项
   * @param {string} key - 键名
   * @param {*} value - 值
   */
  set(key, value) {
    try {
      const data = {
        value,
        timestamp: Date.now(),
        version: '1.0'
      };
      localStorage.setItem(this._getKey(key), JSON.stringify(data));
      return true;
    } catch (e) {
      return false;
    }
  },

  /**
   * 获取存储项
   * @param {string} key - 键名
   * @param {*} defaultValue - 默认值
   * @returns {*}
   */
  get(key, defaultValue = null) {
    try {
      const data = localStorage.getItem(this._getKey(key));
      if (!data) return defaultValue;
      const parsed = JSON.parse(data);
      return parsed.value;
    } catch (e) {
      return defaultValue;
    }
  },

  /**
   * 移除存储项
   * @param {string} key - 键名
   */
  remove(key) {
    localStorage.removeItem(this._getKey(key));
  },

  /**
   * 清空所有存储
   */
  clear() {
    const keys = Object.keys(localStorage);
    keys.forEach(key => {
      if (key.startsWith(DZ_CONFIG.storagePrefix)) {
        localStorage.removeItem(key);
      }
    });
  }
};

/**
 * 事件管理器
 */
const DZEvents = {
  _listeners: new Map(),

  /**
   * 绑定事件
   * @param {string} event - 事件名
   * @param {Function} callback - 回调函数
   * @param {Object} options - 选项
   */
  on(event, callback, options = {}) {
    if (!this._listeners.has(event)) {
      this._listeners.set(event, []);
    }
    this._listeners.get(event).push({ callback, options });
  },

  /**
   * 解绑事件
   * @param {string} event - 事件名
   * @param {Function} callback - 回调函数
   */
  off(event, callback) {
    if (!this._listeners.has(event)) return;
    const listeners = this._listeners.get(event);
    const index = listeners.findIndex(l => l.callback === callback);
    if (index > -1) {
      listeners.splice(index, 1);
    }
  },

  /**
   * 触发事件
   * @param {string} event - 事件名
   * @param {*} data - 数据
   */
  emit(event, data) {
    if (!this._listeners.has(event)) return;
    this._listeners.get(event).forEach(({ callback }) => {
      try {
        callback(data);
      } catch (e) {
        // 静默处理错误
      }
    });
  }
};

/**
 * 图片懒加载管理器
 */
const DZLazyLoad = {
  observer: null,
  images: new Set(),

  /**
   * 初始化懒加载
   */
  init() {
    if (!('IntersectionObserver' in window)) {
      // 降级方案：直接加载所有图片
      this.loadAll();
      return;
    }

    this.observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          this.loadImage(entry.target);
          this.observer.unobserve(entry.target);
        }
      });
    }, {
      rootMargin: '50px 0px',
      threshold: 0.01
    });

    // 观察所有带有data-src的图片
    DZUtils.$$('img[data-src]').forEach(img => {
      this.observer.observe(img);
    });
  },

  /**
   * 加载单张图片
   * @param {HTMLImageElement} img - 图片元素
   */
  loadImage(img) {
    const src = img.dataset.src;
    if (!src) return;

    img.classList.add('loading');
    
    const tempImg = new Image();
    tempImg.onload = () => {
      img.src = src;
      img.classList.remove('loading');
      img.classList.add('loaded');
      img.removeAttribute('data-src');
    };
    tempImg.onerror = () => {
      img.classList.remove('loading');
      img.classList.add('error');
      img.src = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="100" height="100"%3E%3Crect width="100" height="100" fill="%23ccc"/%3E%3Ctext x="50" y="50" text-anchor="middle" dy=".3em" fill="%23999"%3E图片加载失败%3C/text%3E%3C/svg%3E';
    };
    tempImg.src = src;
  },

  /**
   * 加载所有图片（降级方案）
   */
  loadAll() {
    DZUtils.$$('img[data-src]').forEach(img => {
      this.loadImage(img);
    });
  },

  /**
   * 刷新观察列表
   */
  refresh() {
    if (!this.observer) return;
    DZUtils.$$('img[data-src]').forEach(img => {
      this.observer.observe(img);
    });
  }
};

/**
 * 主应用对象
 */
const DingzhouApp = {
  /**
   * 初始化应用
   */
  init() {
    this.initTheme();
    this.initStorage();
    this.initEvents();
    this.initLazyLoad();
    this.initComponents();
    this.loadModalComponents();
    
    // 触发应用就绪事件
    DZEvents.emit('app:ready');
  },

  /**
   * 初始化主题
   */
  initTheme() {
    const savedTheme = DZStorage.get('darkMode', false);
    DZ_STATE.isDarkMode = savedTheme;
    
    if (savedTheme) {
      document.documentElement.classList.add('dark-mode');
    }
  },

  /**
   * 初始化存储
   */
  initStorage() {
    // 加载点赞数据
    const likedItems = DZStorage.get('likedItems', []);
    DZ_STATE.likedItems = new Set(likedItems);
    
    // 加载收藏数据
    const savedItems = DZStorage.get('savedItems', []);
    DZ_STATE.savedItems = new Set(savedItems);
    
    // 加载未读消息数
    DZ_STATE.unreadMessages = DZStorage.get('unreadMessages', 0);
  },

  /**
   * 初始化全局事件
   */
  initEvents() {
    // 页面可见性变化
    document.addEventListener('visibilitychange', () => {
      DZEvents.emit('visibility:change', document.hidden);
    });

    // 窗口大小变化（节流）
    window.addEventListener('resize', DZUtils.throttle(() => {
      DZEvents.emit('window:resize');
    }, 250));

    // 滚动事件（节流）
    window.addEventListener('scroll', DZUtils.throttle(() => {
      DZEvents.emit('window:scroll');
    }, 100));

    // 点击外部关闭菜单
    document.addEventListener('click', (e) => {
      const sideMenu = DZUtils.$('#side-menu');
      const menuBtn = DZUtils.$('#menu-btn');
      
      if (DZ_STATE.isMenuOpen && sideMenu && !sideMenu.contains(e.target) && 
          menuBtn && !menuBtn.contains(e.target)) {
        this.closeMenu();
      }
    });

    // ESC键关闭模态框
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        this.closeAllModals();
        this.closeMenu();
        this.closeMessagePanel();
      }
    });
  },

  /**
   * 初始化懒加载
   */
  initLazyLoad() {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => DZLazyLoad.init());
    } else {
      DZLazyLoad.init();
    }
  },

  /**
   * 初始化组件
   */
  async initComponents() {
    // 加载公共组件
    const components = ['navbar', 'footer', 'message-panel', 'side-menu'];
    for (const name of components) {
      await this.loadComponent(name);
    }
    
    // 初始化组件事件
    this.initComponentEvents();
  },

  /**
   * 加载组件
   * @param {string} name - 组件名称
   */
  async loadComponent(name) {
    const container = DZUtils.$(`#${name}-container`);
    if (!container) return;

    try {
      const response = await fetch(`components/${name}.html`);
      if (!response.ok) throw new Error(`Failed to load ${name}`);
      const html = await response.text();
      container.innerHTML = html;
      DZEvents.emit(`component:loaded`, { name });
    } catch (error) {
      // 使用内联组件作为后备
      this.loadInlineComponent(name, container);
    }
  },

  /**
   * 加载内联组件（后备方案）
   * @param {string} name - 组件名称
   * @param {Element} container - 容器元素
   */
  loadInlineComponent(name, container) {
    const components = {
      'navbar': `
        <nav class="navbar glass-card">
          <div class="navbar-container container">
            <a href="index.html" class="navbar-brand">定州文旅</a>
            <div class="navbar-actions">
              <button id="search-btn" class="navbar-btn" title="搜索"><i class="fa fa-search"></i></button>
              <button id="message-btn" class="navbar-btn" title="消息"><i class="fa fa-bell"></i><span id="message-badge" class="navbar-badge" style="display: none;">0</span></button>
              <button id="menu-btn" class="navbar-btn" title="菜单"><i class="fa fa-bars"></i></button>
            </div>
          </div>
        </nav>`,
      'footer': `
        <footer class="footer-nav glass-card">
          <div class="footer-nav-container container">
            <a href="index.html" class="footer-nav-item" data-page="index"><i class="fa fa-home"></i><span>首页</span></a>
            <a href="discussion.html" class="footer-nav-item" data-page="discussion"><i class="fa fa-comments"></i><span>讨论</span></a>
            <a href="map.html" class="footer-nav-item" data-page="map"><i class="fa fa-map-marker"></i><span>地图</span></a>
            <a href="profile.html" class="footer-nav-item" data-page="profile"><i class="fa fa-user"></i><span>我的</span></a>
          </div>
        </footer>`,
      'side-menu': `
        <div id="side-menu-overlay" class="side-menu-overlay"></div>
        <aside id="side-menu" class="side-menu glass-card">
          <div class="side-menu-header">
            <h2 class="side-menu-title">菜单</h2>
            <button class="side-menu-close" onclick="DingzhouApp.closeMenu()"><i class="fa fa-times"></i></button>
          </div>
          <div class="side-menu-content">
            <div class="side-menu-item" onclick="DingzhouApp.toggleDarkMode()"><i class="fa fa-moon-o"></i><span>深色模式</span></div>
            <div class="side-menu-item" onclick="DingzhouApp.showSettingsModal()"><i class="fa fa-cog"></i><span>设置</span></div>
            <div class="side-menu-item" onclick="DingzhouApp.showAboutModal()"><i class="fa fa-info-circle"></i><span>关于我们</span></div>
            <div class="side-menu-item" onclick="DingzhouApp.shareApp()"><i class="fa fa-share-alt"></i><span>分享应用</span></div>
            <div class="side-menu-item" onclick="DingzhouApp.navigate('feedback.html')"><i class="fa fa-commenting"></i><span>意见反馈</span></div>
          </div>
        </aside>`,
      'message-panel': `
        <div id="message-panel-overlay" class="side-menu-overlay" onclick="DingzhouApp.closeMessagePanel()"></div>
        <aside id="message-panel" class="message-panel glass-card">
          <div class="message-panel-header">
            <h2 class="message-panel-title"><i class="fa fa-bell mr-2"></i>消息中心</h2>
            <button class="message-panel-close" onclick="DingzhouApp.closeMessagePanel()"><i class="fa fa-times"></i></button>
          </div>
          <div class="message-list" id="message-list">
            <div class="message-item"><div class="message-item-header"><div class="message-icon primary"><i class="fa fa-star"></i></div><div class="message-content"><div class="message-title">欢迎来到定州文旅</div><div class="message-text">感谢您使用我们的应用！</div></div><div class="message-time">刚刚</div></div></div>
          </div>
          <div class="message-panel-footer">
            <button class="btn btn-glass" onclick="DingzhouApp.clearAllMessages()"><i class="fa fa-trash-o mr-2"></i>清空消息</button>
          </div>
        </aside>`
    };
    
    if (components[name]) {
      container.innerHTML = components[name];
      DZEvents.emit(`component:loaded`, { name, inline: true });
    }
  },

  /**
   * 加载模态框组件
   */
  loadModalComponents() {
    const modalContainers = {
      'search-modal-container': `
        <div id="search-modal" class="modal search-modal">
          <div class="modal-backdrop" onclick="DingzhouApp.closeAllModals()"></div>
          <div class="modal-content glass-card">
            <div class="modal-header">
              <h3 class="modal-title"><i class="fa fa-search mr-2"></i>搜索</h3>
              <button class="modal-close" onclick="DingzhouApp.closeAllModals()"><i class="fa fa-times"></i></button>
            </div>
            <div class="modal-body">
              <div class="search-input-wrapper">
                <input type="text" id="search-input" class="search-input" placeholder="搜索景点、美食、年俗...">
                <button class="search-btn" onclick="DingzhouApp.performSearch()"><i class="fa fa-search"></i></button>
              </div>
              <div id="search-results" class="search-results">
                <div class="text-center text-gray-400 py-8"><i class="fa fa-search fa-3x mb-4"></i><p>输入关键词开始搜索</p></div>
              </div>
            </div>
          </div>
        </div>`,
      'settings-modal-container': `
        <div id="settings-modal" class="modal">
          <div class="modal-backdrop" onclick="DingzhouApp.closeAllModals()"></div>
          <div class="modal-content glass-card">
            <div class="modal-header">
              <h3 class="modal-title"><i class="fa fa-cog mr-2"></i>设置</h3>
              <button class="modal-close" onclick="DingzhouApp.closeAllModals()"><i class="fa fa-times"></i></button>
            </div>
            <div class="modal-body">
              <div class="settings-item">
                <div><div class="settings-label">深色模式</div><div class="settings-desc">切换应用的深色/浅色主题</div></div>
                <label class="toggle"><input type="checkbox" id="dark-mode-toggle" onchange="DingzhouApp.toggleDarkMode()"><span class="toggle-slider"></span></label>
              </div>
              <div class="settings-item">
                <div><div class="settings-label">消息通知</div><div class="settings-desc">接收应用更新和活动通知</div></div>
                <label class="toggle"><input type="checkbox" id="notification-toggle" checked><span class="toggle-slider"></span></label>
              </div>
              <div class="settings-item">
                <div><div class="settings-label">清除缓存</div><div class="settings-desc">清除本地存储的数据</div></div>
                <button class="btn btn-glass" onclick="DingzhouApp.clearCache()"><i class="fa fa-trash"></i></button>
              </div>
            </div>
            <div class="modal-footer">
              <button class="btn btn-primary flex-1" onclick="DingzhouApp.saveSettings()"><i class="fa fa-check mr-2"></i>保存设置</button>
            </div>
          </div>
        </div>`,
      'about-modal-container': `
        <div id="about-modal" class="modal about-modal">
          <div class="modal-backdrop" onclick="DingzhouApp.closeAllModals()"></div>
          <div class="modal-content glass-card">
            <div class="modal-header">
              <h3 class="modal-title">关于我们</h3>
              <button class="modal-close" onclick="DingzhouApp.closeAllModals()"><i class="fa fa-times"></i></button>
            </div>
            <div class="modal-body p-0">
              <div class="about-hero">
                <h1 class="about-title">定州文旅</h1>
                <div class="about-tags">
                  <span class="about-tag tag-blue">探索</span>
                  <span class="about-tag tag-purple">发现</span>
                  <span class="about-tag tag-pink">体验</span>
                </div>
              </div>
              <div class="about-section">
                <h4 class="about-section-title">关于项目</h4>
                <p class="text-gray-300 mb-4">定州文旅是一款专注于展示定州古城魅力的旅游应用。</p>
              </div>
              <div class="about-section">
                <h4 class="about-section-title">联系我们</h4>
                <div class="about-info-item"><i class="fa fa-envelope text-blue-400"></i><div><div class="font-semibold">邮箱</div><div class="text-gray-400 text-sm">contact@dingzhou-travel.com</div></div></div>
              </div>
            </div>
            <div class="about-footer"><p>© 2024 定州文旅. All rights reserved.</p></div>
          </div>
        </div>`
    };
    
    Object.entries(modalContainers).forEach(([id, html]) => {
      const container = DZUtils.$(`#${id}`);
      if (container && !container.innerHTML.trim()) {
        container.innerHTML = html;
      }
    });
  },

  /**
   * 初始化组件事件
   */
  initComponentEvents() {
    // 菜单按钮
    const menuBtn = DZUtils.$('#menu-btn');
    if (menuBtn) {
      menuBtn.addEventListener('click', () => this.toggleMenu());
    }

    // 消息按钮
    const messageBtn = DZUtils.$('#message-btn');
    if (messageBtn) {
      messageBtn.addEventListener('click', () => this.toggleMessagePanel());
    }

    // 搜索按钮
    const searchBtn = DZUtils.$('#search-btn');
    if (searchBtn) {
      searchBtn.addEventListener('click', () => this.openSearchModal());
    }
  },

  /**
   * 切换菜单
   */
  toggleMenu() {
    DZ_STATE.isMenuOpen = !DZ_STATE.isMenuOpen;
    const sideMenu = DZUtils.$('#side-menu');
    const overlay = DZUtils.$('#side-menu-overlay');
    
    if (sideMenu) {
      sideMenu.classList.toggle('open', DZ_STATE.isMenuOpen);
    }
    if (overlay) {
      overlay.classList.toggle('open', DZ_STATE.isMenuOpen);
    }
    
    DZEvents.emit('menu:toggle', DZ_STATE.isMenuOpen);
  },

  /**
   * 关闭菜单
   */
  closeMenu() {
    DZ_STATE.isMenuOpen = false;
    const sideMenu = DZUtils.$('#side-menu');
    const overlay = DZUtils.$('#side-menu-overlay');
    
    if (sideMenu) sideMenu.classList.remove('open');
    if (overlay) overlay.classList.remove('open');
    
    DZEvents.emit('menu:close');
  },

  /**
   * 切换消息面板
   */
  toggleMessagePanel() {
    DZ_STATE.isMessagePanelOpen = !DZ_STATE.isMessagePanelOpen;
    const panel = DZUtils.$('#message-panel');
    
    if (panel) {
      panel.classList.toggle('open', DZ_STATE.isMessagePanelOpen);
    }
    
    if (DZ_STATE.isMessagePanelOpen) {
      this.markAllMessagesRead();
    }
    
    DZEvents.emit('messagePanel:toggle', DZ_STATE.isMessagePanelOpen);
  },

  /**
   * 关闭消息面板
   */
  closeMessagePanel() {
    DZ_STATE.isMessagePanelOpen = false;
    const panel = DZUtils.$('#message-panel');
    if (panel) panel.classList.remove('open');
    DZEvents.emit('messagePanel:close');
  },

  /**
   * 标记所有消息已读
   */
  markAllMessagesRead() {
    DZ_STATE.unreadMessages = 0;
    DZStorage.set('unreadMessages', 0);
    
    const badge = DZUtils.$('#message-badge');
    if (badge) badge.style.display = 'none';
    
    DZEvents.emit('messages:read');
  },

  /**
   * 关闭所有模态框
   */
  closeAllModals() {
    DZUtils.$$('.modal.open').forEach(modal => {
      modal.classList.remove('open');
    });
    DZEvents.emit('modals:closeAll');
  },

  /**
   * 打开搜索模态框
   */
  openSearchModal() {
    const modal = DZUtils.$('#search-modal');
    if (modal) {
      modal.classList.add('open');
      const input = modal.querySelector('input');
      if (input) input.focus();
    }
    DZEvents.emit('search:open');
  },

  /**
   * 显示Toast提示
   * @param {string} message - 消息内容
   * @param {string} type - 类型：success, error, info, warning
   * @param {number} duration - 显示时长（毫秒）
   */
  showToast(message, type = 'info', duration = 3000) {
    const container = DZUtils.$('#toast-container') || this.createToastContainer();
    
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    
    container.appendChild(toast);
    
    // 触发动画
    requestAnimationFrame(() => {
      toast.classList.add('show');
    });
    
    // 自动移除
    setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => toast.remove(), 300);
    }, duration);
    
    DZEvents.emit('toast:show', { message, type });
  },

  /**
   * 创建Toast容器
   * @returns {HTMLElement}
   */
  createToastContainer() {
    const container = document.createElement('div');
    container.id = 'toast-container';
    container.className = 'toast-container';
    document.body.appendChild(container);
    return container;
  },

  /**
   * 切换深色模式
   */
  toggleDarkMode() {
    DZ_STATE.isDarkMode = !DZ_STATE.isDarkMode;
    document.documentElement.classList.toggle('dark-mode', DZ_STATE.isDarkMode);
    DZStorage.set('darkMode', DZ_STATE.isDarkMode);
    DZEvents.emit('theme:change', DZ_STATE.isDarkMode);
  },

  /**
   * 设置深色模式
   * @param {boolean} enabled - 是否启用
   */
  setDarkMode(enabled) {
    DZ_STATE.isDarkMode = enabled;
    document.documentElement.classList.toggle('dark-mode', enabled);
    DZStorage.set('darkMode', enabled);
    DZEvents.emit('theme:change', enabled);
  },

  /**
   * 切换点赞状态
   * @param {string} id - 项目ID
   * @param {string} type - 类型：attraction, food, custom
   * @returns {boolean} - 当前点赞状态
   */
  toggleLike(id, type) {
    const key = `${type}_${id}`;
    const isLiked = DZ_STATE.likedItems.has(key);
    
    if (isLiked) {
      DZ_STATE.likedItems.delete(key);
    } else {
      DZ_STATE.likedItems.add(key);
    }
    
    DZStorage.set('likedItems', Array.from(DZ_STATE.likedItems));
    DZEvents.emit('like:toggle', { id, type, liked: !isLiked });
    
    return !isLiked;
  },

  /**
   * 检查是否已点赞
   * @param {string} id - 项目ID
   * @param {string} type - 类型
   * @returns {boolean}
   */
  isLiked(id, type) {
    return DZ_STATE.likedItems.has(`${type}_${id}`);
  },

  /**
   * 切换收藏状态
   * @param {string} id - 项目ID
   * @param {string} type - 类型
   * @returns {boolean}
   */
  toggleSave(id, type) {
    const key = `${type}_${id}`;
    const isSaved = DZ_STATE.savedItems.has(key);
    
    if (isSaved) {
      DZ_STATE.savedItems.delete(key);
    } else {
      DZ_STATE.savedItems.add(key);
    }
    
    DZStorage.set('savedItems', Array.from(DZ_STATE.savedItems));
    DZEvents.emit('save:toggle', { id, type, saved: !isSaved });
    
    return !isSaved;
  },

  /**
   * 检查是否已收藏
   * @param {string} id - 项目ID
   * @param {string} type - 类型
   * @returns {boolean}
   */
  isSaved(id, type) {
    return DZ_STATE.savedItems.has(`${type}_${id}`);
  }
};

// 页面加载完成后初始化
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => DingzhouApp.init());
} else {
  DingzhouApp.init();
}

// 导出全局对象
window.DingzhouApp = DingzhouApp;
window.DZUtils = DZUtils;
window.DZStorage = DZStorage;
window.DZEvents = DZEvents;
window.DZLazyLoad = DZLazyLoad;
window.DZ_CONFIG = DZ_CONFIG;
window.DZ_STATE = DZ_STATE;
