/**
 * 工具模块
 * 封装通用工具函数
 */

const UtilsModule = {
    // 分享应用
    shareApp: function() {
        if (navigator.share) {
            navigator.share({
                title: '定州文化之旅',
                text: '探索千年古城定州的魅力，发现历史文化之美！',
                url: window.location.href
            }).then(() => {
                if (typeof showToast === 'function') {
                    showToast('分享成功！');
                }
            }).catch((error) => {
                console.error('分享失败:', error);
                this.fallbackShare();
            });
        } else {
            this.fallbackShare();
        }
    },

    // 备用分享方法
    fallbackShare: function() {
        if (navigator.clipboard) {
            navigator.clipboard.writeText(window.location.href).then(() => {
                if (typeof showToast === 'function') {
                    showToast('链接已复制到剪贴板，快去分享吧！');
                }
            }).catch(() => {
                if (typeof showToast === 'function') {
                    showToast('复制失败，请手动分享');
                }
            });
        } else {
            if (typeof showToast === 'function') {
                showToast('您的浏览器不支持分享功能');
            }
        }
    },

    // 页面跳转
    goToPage: function(page) {
        window.location.href = page;
    },

    // 导航函数
    goToHome: function() {
        window.location.href = 'index.html';
    },

    goToDiscussion: function() {
        if (typeof showToast === 'function') {
            showToast('讨论功能开发中');
        }
    },

    goToMap: function() {
        if (typeof showToast === 'function') {
            showToast('地图功能开发中');
        }
    },

    goToProfile: function() {
        if (typeof showToast === 'function') {
            showToast('个人中心功能开发中');
        }
    },

    goToFeedback: function() {
        window.location.href = 'feedback.html';
    },

    goToHelpCenter: function() {
        window.location.href = 'help-center.html';
    },

    // 显示全部景点
    showAllAttractions: function() {
        if (typeof showToast === 'function') {
            showToast('更多景点功能开发中');
        }
    },

    // 显示全部美食
    showAllFoods: function() {
        if (typeof showToast === 'function') {
            showToast('更多美食功能开发中');
        }
    },

    // 显示全部年俗
    showAllCustoms: function() {
        if (typeof showToast === 'function') {
            showToast('更多年俗功能开发中');
        }
    },

    // 节流函数
    throttle: function(func, limit) {
        let inThrottle;
        return function(...args) {
            if (!inThrottle) {
                func.apply(this, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        };
    },

    // 防抖函数
    debounce: function(func, wait) {
        let timeout;
        return function(...args) {
            clearTimeout(timeout);
            timeout = setTimeout(() => func.apply(this, args), wait);
        };
    },

    // 检查元素是否在视口内
    isInViewport: function(element) {
        const rect = element.getBoundingClientRect();
        return (
            rect.top >= 0 &&
            rect.left >= 0 &&
            rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
            rect.right <= (window.innerWidth || document.documentElement.clientWidth)
        );
    },

    // 格式化日期
    formatDate: function(date) {
        const d = new Date(date);
        return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    }
};

// 导出模块
if (typeof module !== 'undefined' && module.exports) {
    module.exports = UtilsModule;
} else {
    window.UtilsModule = UtilsModule;
    
    // 为了兼容性，保留全局函数
    window.shareApp = UtilsModule.shareApp.bind(UtilsModule);
    window.goToPage = UtilsModule.goToPage.bind(UtilsModule);
    window.goToHome = UtilsModule.goToHome.bind(UtilsModule);
    window.goToDiscussion = UtilsModule.goToDiscussion.bind(UtilsModule);
    window.goToMap = UtilsModule.goToMap.bind(UtilsModule);
    window.goToProfile = UtilsModule.goToProfile.bind(UtilsModule);
    window.goToFeedback = UtilsModule.goToFeedback.bind(UtilsModule);
    window.goToHelpCenter = UtilsModule.goToHelpCenter.bind(UtilsModule);
    window.showAllAttractions = UtilsModule.showAllAttractions.bind(UtilsModule);
    window.showAllFoods = UtilsModule.showAllFoods.bind(UtilsModule);
    window.showAllCustoms = UtilsModule.showAllCustoms.bind(UtilsModule);
}
