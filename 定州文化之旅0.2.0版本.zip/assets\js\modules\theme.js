/**
 * 主题模块
 * 管理深色模式
 */

const ThemeModule = {
    STORAGE_KEY: 'darkMode',

    // 切换深色模式
    toggleDarkMode: function() {
        const toggle = document.getElementById('darkModeToggle');
        if (!toggle) return;

        const isEnabled = toggle.checked;
        localStorage.setItem(this.STORAGE_KEY, isEnabled);
        this.applyDarkMode();
        this.updateLabels(isEnabled);

        if (typeof showToast === 'function') {
            showToast(`已切换为${isEnabled ? '深色' : '浅色'}模式`);
        }
    },

    // 应用深色模式
    applyDarkMode: function() {
        const isEnabled = localStorage.getItem(this.STORAGE_KEY) === 'true';
        
        if (isEnabled) {
            document.body.classList.add('dark-mode');
            document.documentElement.style.setProperty('--tw-bg-opacity', '0.9');
        } else {
            document.body.classList.remove('dark-mode');
            document.documentElement.style.setProperty('--tw-bg-opacity', '1');
        }
    },

    // 更新标签和描述
    updateLabels: function(isEnabled) {
        const label = document.getElementById('darkModeLabel');
        const description = document.getElementById('darkModeDescription');
        
        if (label) {
            label.textContent = isEnabled ? '深色模式' : '浅色模式';
        }
        if (description) {
            description.textContent = isEnabled 
                ? '当前为深色模式，点击关闭。' 
                : '当前为浅色模式，点击开启深色模式。';
        }
    },

    // 加载设置
    loadSettings: function() {
        const darkMode = localStorage.getItem(this.STORAGE_KEY) === 'true';
        const toggle = document.getElementById('darkModeToggle');
        
        if (toggle) {
            toggle.checked = darkMode;
        }
        
        this.updateLabels(darkMode);
    },

    // 初始化
    init: function() {
        this.applyDarkMode();
        this.loadSettings();
        console.log('Theme module initialized');
    }
};

// 导出模块
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ThemeModule;
} else {
    window.ThemeModule = ThemeModule;
    
    // 为了兼容性，保留全局函数
    window.toggleDarkMode = ThemeModule.toggleDarkMode.bind(ThemeModule);
    window.applyDarkMode = ThemeModule.applyDarkMode.bind(ThemeModule);
    window.loadSettings = ThemeModule.loadSettings.bind(ThemeModule);
}
