/**
 * 浏览器兼容性模块
 * 检测浏览器特性并提供降级方案
 */

const BrowserCompat = {
    // 兼容性检测结果
    features: {},

    // 最低支持的浏览器版本
    minVersions: {
        chrome: 60,
        firefox: 60,
        safari: 12,
        edge: 79,
        ie: 11
    },

    /**
     * 初始化兼容性检测
     */
    init: function() {
        this.detectFeatures();
        
        if (!this.isSupported()) {
            this.showUnsupportedWarning();
        }
        
        console.log('Browser compatibility checked:', this.features);
    },

    /**
     * 检测浏览器特性
     */
    detectFeatures: function() {
        this.features = {
            // ES6+ 特性
            promises: typeof Promise !== 'undefined',
            fetch: typeof fetch !== 'undefined',
            arrowFunctions: (() => true)(),
            templateLiterals: (function() { try { eval('`test`'); return true; } catch(e) { return false; } })(),
            
            // DOM API
            querySelector: !!document.querySelector,
            classList: 'classList' in document.createElement('div'),
            addEventListener: !!window.addEventListener,
            localStorage: this.checkLocalStorage(),
            
            // CSS 特性
            flexbox: this.checkCSSFeature('display', 'flex'),
            grid: this.checkCSSFeature('display', 'grid'),
            transforms: this.checkCSSFeature('transform', 'translateX(1px)'),
            transitions: this.checkCSSFeature('transition', 'all 1s'),
            
            // 现代 API
            intersectionObserver: typeof IntersectionObserver !== 'undefined',
            resizeObserver: typeof ResizeObserver !== 'undefined',
            mutationObserver: typeof MutationObserver !== 'undefined',
            
            // 网络 API
            online: navigator.onLine !== undefined,
            geolocation: 'geolocation' in navigator,
            
            // 媒体 API
            webp: this.checkWebPSupport(),
            
            // 触摸支持
            touch: 'ontouchstart' in window || navigator.maxTouchPoints > 0,
            
            // 性能 API
            performance: typeof performance !== 'undefined' && performance.now
        };
    },

    /**
     * 检查localStorage是否可用
     */
    checkLocalStorage: function() {
        try {
            const test = '__test__';
            localStorage.setItem(test, test);
            localStorage.removeItem(test);
            return true;
        } catch (e) {
            return false;
        }
    },

    /**
     * 检查CSS特性支持
     */
    checkCSSFeature: function(property, value) {
        const testEl = document.createElement('div');
        testEl.style[property] = value;
        return testEl.style[property] === value;
    },

    /**
     * 检查WebP支持
     */
    checkWebPSupport: function() {
        const canvas = document.createElement('canvas');
        if (canvas.getContext && canvas.getContext('2d')) {
            return canvas.toDataURL('image/webp').indexOf('data:image/webp') === 0;
        }
        return false;
    },

    /**
     * 获取浏览器信息
     */
    getBrowserInfo: function() {
        const ua = navigator.userAgent;
        let browser = 'unknown';
        let version = 0;

        if (ua.indexOf('Chrome') > -1 && ua.indexOf('Edg') === -1) {
            browser = 'chrome';
            version = parseInt(ua.match(/Chrome\/(\d+)/)?.[1] || 0);
        } else if (ua.indexOf('Firefox') > -1) {
            browser = 'firefox';
            version = parseInt(ua.match(/Firefox\/(\d+)/)?.[1] || 0);
        } else if (ua.indexOf('Safari') > -1 && ua.indexOf('Chrome') === -1) {
            browser = 'safari';
            version = parseInt(ua.match(/Version\/(\d+)/)?.[1] || 0);
        } else if (ua.indexOf('Edg') > -1) {
            browser = 'edge';
            version = parseInt(ua.match(/Edg\/(\d+)/)?.[1] || 0);
        } else if (ua.indexOf('Trident') > -1 || ua.indexOf('MSIE') > -1) {
            browser = 'ie';
            version = parseInt(ua.match(/(?:MSIE |rv:)(\d+)/)?.[1] || 0);
        }

        return { browser, version, ua };
    },

    /**
     * 检查浏览器是否受支持
     */
    isSupported: function() {
        const info = this.getBrowserInfo();
        const minVersion = this.minVersions[info.browser];
        
        if (!minVersion) return true; // 未知浏览器，假设支持
        
        return info.version >= minVersion;
    },

    /**
     * 显示不支持的警告
     */
    showUnsupportedWarning: function() {
        const info = this.getBrowserInfo();
        const warning = document.createElement('div');
        warning.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            background: #ff6b6b;
            color: white;
            padding: 15px;
            text-align: center;
            z-index: 99999;
            font-family: sans-serif;
            font-size: 14px;
        `;
        warning.innerHTML = `
            <strong>浏览器版本过低</strong><br>
            您的 ${info.browser} ${info.version} 版本过低，部分功能可能无法正常使用。<br>
            建议升级到最新版本以获得最佳体验。
        `;
        document.body.appendChild(warning);
    },

    /**
     * 获取缺失的关键特性
     */
    getMissingCriticalFeatures: function() {
        const critical = ['promises', 'fetch', 'localStorage', 'querySelector', 'classList'];
        return critical.filter(feature => !this.features[feature]);
    },

    /**
     * 是否需要Polyfill
     */
    needsPolyfill: function() {
        return this.getMissingCriticalFeatures().length > 0;
    },

    /**
     * 加载Polyfill
     */
    loadPolyfills: function() {
        const missing = this.getMissingCriticalFeatures();
        
        if (missing.includes('promises') || missing.includes('fetch')) {
            this.loadScript('https://cdn.jsdelivr.net/npm/promise-polyfill@8/dist/polyfill.min.js');
            this.loadScript('https://cdn.jsdelivr.net/npm/whatwg-fetch@3.6.2/dist/fetch.umd.min.js');
        }
    },

    /**
     * 加载脚本
     */
    loadScript: function(src) {
        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            script.src = src;
            script.onload = resolve;
            script.onerror = reject;
            document.head.appendChild(script);
        });
    },

    /**
     * 提供降级方案
     */
    getFallback: function(feature) {
        const fallbacks = {
            localStorage: {
                getItem: () => null,
                setItem: () => {},
                removeItem: () => {}
            },
            fetch: (url) => {
                return new Promise((resolve, reject) => {
                    const xhr = new XMLHttpRequest();
                    xhr.open('GET', url);
                    xhr.onload = () => resolve({
                        json: () => Promise.resolve(JSON.parse(xhr.responseText))
                    });
                    xhr.onerror = reject;
                    xhr.send();
                });
            }
        };
        
        return fallbacks[feature];
    }
};

// 导出模块
if (typeof module !== 'undefined' && module.exports) {
    module.exports = BrowserCompat;
} else {
    window.BrowserCompat = BrowserCompat;
}
